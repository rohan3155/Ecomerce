import  express  from "express";
import { create, search } from "../Controller/AUserController.js";
import { view } from "../Controller/AUserController.js";
import { update } from "../Controller/AUserController.js";
import { del } from "../Controller/AUserController.js";

const Auserrouter = express.Router();
Auserrouter.post('/create',create);
Auserrouter.post('/view',view);
Auserrouter.post('/update',update);
Auserrouter.post('/delete' ,del);
Auserrouter.post('/search' ,search);

export {Auserrouter}