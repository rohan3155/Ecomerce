import  express  from "express";
import { login } from "../Controller/ULogincontroler.js"
import { add } from "../Controller/USignUpcontroler.js"
import  {mid, mid2}  from "../Middleware/USignUpMiddleware.js";
import { mid3,  uidc } from "../Middleware/ULoginMiddleware.js";
const Urouter = express.Router();
Urouter.post('/signup',mid,mid2, add);
Urouter.post('/login',mid3,login,uidc);


export  {Urouter};

