import  express  from "express";
import { orders } from "../Controller/OrdersController.js";

const orderrouter = express.Router();
orderrouter.post('/orders',orders);
export {orderrouter};