import  express  from "express";
import { create } from "../Controller/ProductController.js";
import { view } from "../Controller/ProductController.js";
import { update } from "../Controller/ProductController.js";
import { del} from "../Controller/ProductController.js";
import {prodel } from "../Middleware/ProductMiddleware.js";
const Prodrouter = express.Router();
Prodrouter.post('/Pcreate',create);
Prodrouter.post('/Pview',view);
Prodrouter.post('/Pupdate',update);
// Prodrouter.post('/Addimage',Addimage);
Prodrouter.post('/Pdelete',prodel ,del);

export {Prodrouter}