import  express  from "express";
import { add, buy, remove, update, view } from "../Controller/CartController.js";
// import { catdel } from "../Middleware/CartMiddleware.js";

const cartrouter = express.Router();
cartrouter.post('/addtocart',add);
cartrouter.post('/buy',buy);
cartrouter.post('/viewcart',view);
cartrouter.post('/updatecart',update);
cartrouter.post('/removefromcart' ,remove);

export {cartrouter}