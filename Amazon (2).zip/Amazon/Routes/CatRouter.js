import  express  from "express";
import { create } from "../Controller/CatController.js";
import { view } from "../Controller/CatController.js";
import { update } from "../Controller/CatController.js";
import { del} from "../Controller/CatController.js";
import { cat } from "../Middleware/CatMiddleware.js";

const catrouter = express.Router();
catrouter.post('/Ccreate',cat ,create);
catrouter.post('/Cview',view);
catrouter.post('/Cupdate',update);
catrouter.post('/Cdelete' ,del);

export {catrouter}