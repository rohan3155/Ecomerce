import  express  from "express";
import { view } from "../Controller/UProdController.js";
// import { } from "../Middleware/UProdMiddleware.js";
const UProdrouter = express.Router();
UProdrouter.post('/products',view);
export {UProdrouter}