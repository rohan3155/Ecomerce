import  express  from "express";
import { login } from "../Controller/ALogincontroler.js"
import { add } from "../Controller/ASignUpcontroler.js"
import  {mid, mid2}  from "../Middleware/ASignUpMiddleware.js";
import { mid3, mid4 } from "../Middleware/ALoginMiddleware.js";
const Arouter = express.Router();
Arouter.post('/signup',mid,mid2, add);
Arouter.post('/login',mid3,mid4,login);

export  {Arouter};

