import  express  from "express";
import { add, remove, update, view } from "../Controller/UaddressController.js";
import { catdel } from "../Middleware/UaddressMiddleware.js";

const addressrouter = express.Router();
addressrouter.get('/addaddress',add);
addressrouter.get('/viewaddress',view);
addressrouter.get('/updateaddress',update);
addressrouter.get('/removeaddress',catdel ,remove);

export {addressrouter}