import express from 'express';
import mongoose from 'mongoose';
import cors from 'cors';
import  {Urouter}  from './Routes/Urouter.js';
import  {Arouter}  from './Routes/Arouter.js';
import {catrouter} from './Routes/CatRouter.js';
import {Prodrouter} from './Routes/ProdRouter.js';
import {UProdrouter} from './Routes/UprodRouter.js';
import { cartrouter } from './Routes/CartRouter.js';
import { addressrouter } from './Routes/UaddressRouter.js';
import { orderrouter } from './Routes/OrderRouter.js';
import { Auserrouter } from './Routes/AUserRouter.js';
import {Imagerouter} from './Routes/ImageRouter.js'
const app = express();

app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use('/img',express.static('C:/Users/bhati/Desktop/Amazon new/Amazon/imagesfolder'));
app.use(cors());
app.use("/user",Urouter);
app.use("/admin",Urouter);
app.use("/admin",Arouter);
app.use("/admin",catrouter);
app.use("/user",cartrouter);
app.use("/user",addressrouter);
app.use("/admin",Prodrouter);
app.use("/admin",Imagerouter);
app.use("/admin", orderrouter);
app.use("/user",UProdrouter);
app.use("/admin",Auserrouter);
const mongodb = "mongodb://127.0.0.1:27017/Ecomercedb";
mongoose.set('strictQuery', true);
mongoose.connect(mongodb)
.then((res) => {
    
    console.log('Connected to MongoDB');
   
})
.catch((err) => {
    console.log(err);
});

app.listen(3155);