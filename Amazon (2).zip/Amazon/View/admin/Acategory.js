function Vcategories() {

    var req = {


    };


    $.ajax({
        type: "post",
        url: "http://localhost:3155/admin/Cview",

        headers: {

        },
          data: JSON.stringify(req),
        success: function (res) {

            console.log(res);


            document.getElementById("table").innerHTML = `<thead>
            <tr>
              <th
                class="whitespace-nowrap px-4 py-2 text-left font-medium text-gray-900"
              >
                Categories
              </th>
             
              <th class="px-4 py-2"></th>
            </tr>
          </thead>
        
           
         <center>
         <tbody class="divide-y divide-gray-200" id="table-body">
         
         </tbody>
         </center>
`
            let Ndata = "";
            console.log(Object.keys(res[0]))
            res.forEach((value, index) => {
                Ndata += ` 

                <tr>
                <td class="whitespace-nowrap px-4 py-2 font-medium text-gray-900" id="name">
                ${value.category}
                </td>
                <td class="whitespace-nowrap px-4 py-2">
                <span
                class="inline-flex divide-x overflow-hidden rounded-md border bg-white shadow-sm"
              >
                <button
                onclick="editCategory('${value._id}')"
                  class="inline-block p-3 text-gray-700 hover:bg-gray-50 focus:relative"
                  title="Edit Product"
                >
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    fill="none"
                    viewBox="0 0 24 24"
                    stroke-width="1.5"
                    stroke="currentColor"
                    class="h-4 w-4"
                  >
                    <path
                      stroke-linecap="round"
                      stroke-linejoin="round"
                      d="M16.862 4.487l1.687-1.688a1.875 1.875 0 112.652 2.652L10.582 16.07a4.5 4.5 0 01-1.897 1.13L6 18l.8-2.685a4.5 4.5 0 011.13-1.897l8.932-8.931zm0 0L19.5 7.125M18 14v4.75A2.25 2.25 0 0115.75 21H5.25A2.25 2.25 0 013 18.75V8.25A2.25 2.25 0 015.25 6H10"
                    />
                  </svg>
                </button>
              
                <button
                onclick="Cdeleter('${value._id}')"
                  class="inline-block p-3 text-gray-700 hover:bg-gray-50 focus:relative"
                  title="Delete Product"
                >
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    fill="none"
                    viewBox="0 0 24 24"
                    stroke-width="1.5"
                    stroke="currentColor"
                    class="h-4 w-4"
                  >
                    <path
                      stroke-linecap="round"
                      stroke-linejoin="round"
                      d="M14.74 9l-.346 9m-4.788 0L9.26 9m9.968-3.21c.342.052.682.107 1.022.166m-1.022-.165L18.16 19.673a2.25 2.25 0 01-2.244 2.077H8.084a2.25 2.25 0 01-2.244-2.077L4.772 5.79m14.456 0a48.108 48.108 0 00-3.478-.397m-12 .562c.34-.059.68-.114 1.022-.165m0 0a48.11 48.11 0 013.478-.397m7.5 0v-.916c0-1.18-.91-2.164-2.09-2.201a51.964 51.964 0 00-3.32 0c-1.18.037-2.09 1.022-2.09 2.201v.916m7.5 0a48.667 48.667 0 00-7.5 0"
                    />
                  </svg>
                </button>
              </span>
              
                </td>
            
        `
            });

            document.getElementById("table-body").innerHTML = Ndata;
        },
        error: function (req, err) {
            alert("Failed");
            console.log(err);
        },

    });
}
function editCategory(_id) {
  console.log(_id)
  const filter = {
    _id : _id
  }
  
  //view user by id
  $.ajax({
    type: "post",
    url: "http://localhost:3155/admin/Cview",
    data: JSON.stringify(filter),
    contentType: "application/json",
    headers:{
      
    },
    success: function (res) {
      let id = res[0]._id
      let category = res[0].category
     
  console.log(category)
      
  
          document.getElementById("table").innerHTML = ` 
              <div class="container">
          <center>
            <h1 class="text-4xl text-[#0f172a] pt-6 ">Edit Details</h1>
           
              <div id="form">
                </div>
              <button type="button" onclick="Cupdater()" class="px-[8rem] py-3 text-white rounded-2xl mt-4   bg-gradient-to-r from-green-400 to-blue-500 hover:from-pink-500 hover:to-yellow-500 " onclick="signup()">
                Submit</button>
             
            </form>
          </center>
          </div>`
  
  
          let data = "";
            
             
               
                
                 data = ` 
                 <div class="w-full max-w-lg">
                 <form class="bg-white shadow-md rounded px-8 pt-6 pb-8 mb-4">                
               <div class="name mt-4">
               <div class="id mt-4">
                 <input type="text" name="id" id="id" 
                 class="shadow appearance-none border visibility: hidden rounded w-[30%] py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline ">
             </div>
               <div class="categoryId mt-4">
               <label for="categoryId" class="block text-gray-700 text-sm font-bold mb-2">Category</label> <br>
               <input type="text" name="category" id="category" 
                            class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline "
             </div>
           </div>
           </form>
           </div>
               `
               document.getElementById("form").innerHTML = data;
               
               document.getElementById("id").value= id
               document.getElementById("category").value= category
          
    }
  
  })
  
  }
  
  function Cupdater() {
    var req = {
      filter:
      {
        _id: document.getElementById("id").value,
      },
      data:
      {
         category:document.getElementById("category").value
      }
    
    
    
    };
    
    $.ajax({
    type: "post",
    url: "http://localhost:3155/admin/Cupdate",
    
    headers: {
    
    },
      data: JSON.stringify(req),
    success: function (res) {
    console.log(res);
    },
    error: function (req, err) {
    
    console.log(err);
    },
    
    });
    }
    function Cdeleter(_id) {
      console.log(_id)
      var req = {
        filter:
        {
          _id:_id
        }
       
      
      
      
      };
      
      $.ajax({
      type: "post",
      url: "http://localhost:3155/admin/Cdelete",
      
      headers: {
      
      },
        data: (req),
      success: function (res) {
      console.log(res);
      
      Vcategories();
      },
      error: function (req, err) {
      
      console.log(err);
      },
      
      });
      }

      function AddCategory() {

        var req = {
        
        
        };
        $.ajax({
        type: "post",
        url: "http://localhost:3155/admin/Ccreate",
        
        headers: {
        
        },
          data: JSON.stringify(req),
        success: function (res) {
        
            console.log(res);
        
        
            document.getElementById("table").innerHTML = `
           
            <div class="container">
        <center>
          <h1 class="text-4xl text-[#0f172a] pt-6 ">Add Category</h1>
          
              <div class="categoryId mt-4">
                <label for="categoryId" class="block text-gray-700 text-sm font-bold mb-2">Category</label> <br>
                <input type="text" name="category" id="category" 
                class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline ">
              </div>
             
            <button type="button" class="px-[8rem] py-3 text-white rounded-2xl mt-4   bg-gradient-to-r from-green-400 to-blue-500 hover:from-pink-500 hover:to-yellow-500 " onclick="catadd()">
              Submit</button>
        
        </center>
        </div>
        
        
        `
            
        },
        error: function (req, err) {
            alert("Failed");
            console.log(err);
        },
        
        });
        }
        function catadd() {
        
        var req = {
        
        category: document.getElementById("category").value,
        };
        
        $.ajax({
        type: "post",
        url: "http://localhost:3155/admin/Ccreate",
        
        headers: {
        
        },
          data: (req),
        success: function (res) {
        // alert("Done");
        console.log(res);
        document.getElementById("table").innerHTML =`
              <div class="p-4 mb-4 text-sm text-green-800 rounded-lg bg-green-50 dark:bg-gray-800 dark:text-green-400" role="alert">
          <span class="font-medium">${res}</span> 
        </div>
              `
              
        // window.location.href = "/View/user/login.html";
        },
        error: function (req, err) {
        // alert("Failed");
        console.log(err);
        },
        
        });
        }
        
        
        