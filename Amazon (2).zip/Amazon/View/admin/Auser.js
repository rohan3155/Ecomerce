function Vuser() {

  var req = {


  };


  $.ajax({
      type: "post",
      url: "http://localhost:3155/admin/view",

      headers: {

      },
        data: JSON.stringify(req),
      success: function (res) {

          console.log(res);
      

          document.getElementById("table").innerHTML = `
          <thead>
            <tr>
              <th
                class="whitespace-nowrap px-4 py-2 text-left font-medium text-gray-900"
              >
                Name
              </th>
              <th
                class="whitespace-nowrap px-4 py-2 text-left font-medium text-gray-900"
              >
                Phone
              </th>
              <th
                class="whitespace-nowrap px-4 py-2 text-left font-medium text-gray-900"
              >
                Email
              </th>
              <th
                class="whitespace-nowrap px-4 py-2 text-left font-medium text-gray-900"
              >
                Password
              </th>
              <th class="px-4 py-2"></th>
            </tr>
          </thead>
        
           
          <tbody class="divide-y divide-gray-200" id="table-body">
         
        </tbody>
`
          let Ndata = "";
          // console.log(Object.keys(res[0]))
          res.forEach((value, index) => {
              Ndata += ` 
              <tr>
              <td class="whitespace-nowrap px-4 py-2 font-medium text-gray-900" id="name">
              ${value.name}
              </td>
              <td class="whitespace-nowrap px-4 py-2 text-gray-700" id="phone">${value.phone}</td>
              <td class="whitespace-nowrap px-4 py-2 text-gray-700" id="email">${value.email}</td>
              <td class="whitespace-nowrap px-4 py-2 text-gray-700" id="password">${value.password = "👀"}</td>
              <td class="whitespace-nowrap px-4 py-2">
              <span
              class="inline-flex divide-x overflow-hidden rounded-md border bg-white shadow-sm"
            >
              <button
              onclick="Edituser('${value._id}')"
                class="inline-block p-3 text-gray-700 hover:bg-gray-50 focus:relative"
                title="Edit Product"
              >
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  fill="none"
                  viewBox="0 0 24 24"
                  stroke-width="1.5"
                  stroke="currentColor"
                  class="h-4 w-4"
                >
                  <path
                    stroke-linecap="round"
                    stroke-linejoin="round"
                    d="M16.862 4.487l1.687-1.688a1.875 1.875 0 112.652 2.652L10.582 16.07a4.5 4.5 0 01-1.897 1.13L6 18l.8-2.685a4.5 4.5 0 011.13-1.897l8.932-8.931zm0 0L19.5 7.125M18 14v4.75A2.25 2.25 0 0115.75 21H5.25A2.25 2.25 0 013 18.75V8.25A2.25 2.25 0 015.25 6H10"
                  />
                </svg>
              </button>
            
              <button
              onclick="Udeleter('${value._id}')"
                class="inline-block p-3 text-gray-700 hover:bg-gray-50 focus:relative"
                title="Delete Product"
              >
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  fill="none"
                  viewBox="0 0 24 24"
                  stroke-width="1.5"
                  stroke="currentColor"
                  class="h-4 w-4"
                >
                  <path
                    stroke-linecap="round"
                    stroke-linejoin="round"
                    d="M14.74 9l-.346 9m-4.788 0L9.26 9m9.968-3.21c.342.052.682.107 1.022.166m-1.022-.165L18.16 19.673a2.25 2.25 0 01-2.244 2.077H8.084a2.25 2.25 0 01-2.244-2.077L4.772 5.79m14.456 0a48.108 48.108 0 00-3.478-.397m-12 .562c.34-.059.68-.114 1.022-.165m0 0a48.11 48.11 0 013.478-.397m7.5 0v-.916c0-1.18-.91-2.164-2.09-2.201a51.964 51.964 0 00-3.32 0c-1.18.037-2.09 1.022-2.09 2.201v.916m7.5 0a48.667 48.667 0 00-7.5 0"
                  />
                </svg>
              </button>
            </span>
            
              </td>
            </tr>                  
              `
             
          });

          document.getElementById("table-body").innerHTML = Ndata;
      },
      error: function (req, err) {
          alert("Failed");
          console.log(err);
      },

  });
}
function Edituser(_id) {
console.log(_id)
const filter = {
_id : _id
}

//view user by id
$.ajax({
type: "post",
url: "http://localhost:3155/admin/view",
data: JSON.stringify(filter),
contentType: "application/json",
headers:{
  
},
success: function (res) {
  let _id = res[0]._id
  let name = res[0].name
  let email = res[0].email
  let phone = res[0].phone
  let password = res[0].password
console.log(name)
  

      document.getElementById("table").innerHTML = ` 
          <div class="container">
      <center>
        <h1 class="text-4xl text-[#0f172a] pt-6 ">Edit Details</h1>
       
          <div id="form">
            </div>
          <button type="button" onclick="Uupdater()" class="px-[8rem] py-3 text-white rounded-2xl mt-4   bg-gradient-to-r from-green-400 to-blue-500 hover:from-pink-500 hover:to-yellow-500 " onclick="signup()">
            Submit</button>
         
        </form>
      </center>
      </div>`


      let data = "";
        
         
           
            
             data = ` 
             <div class="w-full max-w-lg">
             <form class="bg-white shadow-md rounded px-8 pt-6 pb-8 mb-4">           
           <div class="name mt-4">
           <input type="text" name="name" id="id" visibility: hidden   placeholder="Enter Your Name Here"
             class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline ">
         </div>
         <div class="name mt-4">
         <label for="name" class="block text-gray-700 text-sm font-bold mb-2">Name</label> <br>
         <input type="text" name="name" id="name"   placeholder="Enter Your Name Here"
           class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline ">
       </div>
       <div class="phone mt-4">
         <label for="phone" class="block text-gray-700 text-sm font-bold mb-2">Phone</label> <br>
         <input type="text" name="phone" id="phone"  placeholder="Enter Your Phone Number Here"
           class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline">
       </div>
       <div class="email mt-4">
         <label for="email" class="block text-gray-700 text-sm font-bold mb-2">Email</label> <br>
         <input type="email" name="email" id="email"  placeholder="Enter Your email Here"
           class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline">
       </div>
       <div class="password mt-4">
         <label for="password" class="block text-gray-700 text-sm font-bold mb-2">Password</label> <br>
         <input type="password" name="password"  id="password" placeholder="Enter Your password Here"
           class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline">
       </div>
       </form>
       </div>
           `
           document.getElementById("form").innerHTML = data;
           
           document.getElementById("id").value= _id
           document.getElementById("name").value= name
      document.getElementById("phone").value = phone
      document.getElementById("email").value= email
      document.getElementById("password").value = password
}

})

}


function Uupdater() {
  var req = {
    filter:
    {
      _id: document.getElementById("id").value,
    },
    data:
    {
      name: document.getElementById("name").value,
  phone: document.getElementById("phone").value,
  email: document.getElementById("email").value,
  password: document.getElementById("password").value
    }
  
  
  
  };
  
  $.ajax({
  type: "post",
  url: "http://localhost:3155/admin/update",
  
  headers: {
  
  },
    data: (req),
  success: function (res) {
  // alert("Done");
  console.log(res);
  // window.location.href = "/View/user/login.html";
  },
  error: function (req, err) {
  // alert("Failed");
  console.log(err);
  },
  
  });
  }


function Udeleter(_id) {
  console.log(_id)
  var req = {
    filter:
    {
      _id:_id
    }
   
  
  
  
  };
  
  $.ajax({
  type: "post",
  url: "http://localhost:3155/admin/delete",
  
  headers: {
  
  },
    data: (req),
  success: function (res) {
  console.log(res);
    
  Vuser();
  },
  error: function (req, err) {
  
  console.log(err);
  },
  
  });
  }


  function Adduser() {

    var req = {
    
    
    };
    $.ajax({
    type: "post",
    url: "http://localhost:3155/admin/create",
    
    headers: {
    
    },
      data:(req),
    success: function (res) {
    
        console.log(res);
    
    
        document.getElementById("table").innerHTML = ` 
        <div class="container">
    <center>
      <h1 class="text-4xl text-[#0f172a] pt-6 ">Edit Details</h1>
     
        <div id="form">
          </div>
        <button type="button" onclick="signup()" class="px-[8rem] py-3 text-white rounded-2xl mt-4   bg-gradient-to-r from-green-400 to-blue-500 hover:from-pink-500 hover:to-yellow-500 " onclick="signup()">
          Submit</button>
       
      </form>
    </center>
    </div>`


    let data = "";
      
       
         
          
           data = ` 
           <div class="w-full max-w-lg">
           <form class="bg-white shadow-md rounded px-8 pt-6 pb-8 mb-4">           
         <div class="name mt-4">
         <input type="text" name="name" id="id" visibility: hidden   placeholder="Enter Your Name Here"
           class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline ">
       </div>
       <div class="name mt-4">
       <label for="name" class="block text-gray-700 text-sm font-bold mb-2">Name</label> <br>
       <input type="text" name="name" id="name"   placeholder="Enter Your Name Here"
         class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline ">
     </div>
     <div class="phone mt-4">
       <label for="phone" class="block text-gray-700 text-sm font-bold mb-2">Phone</label> <br>
       <input type="text" name="phone" id="phone"  placeholder="Enter Your Phone Number Here"
         class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline">
     </div>
     <div class="email mt-4">
       <label for="email" class="block text-gray-700 text-sm font-bold mb-2">Email</label> <br>
       <input type="email" name="email" id="email"  placeholder="Enter Your email Here"
         class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline">
     </div>
     <div class="password mt-4">
       <label for="password" class="block text-gray-700 text-sm font-bold mb-2">Password</label> <br>
       <input type="password" name="password"  id="password" placeholder="Enter Your password Here"
         class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline">
     </div>
     </form>
     </div>
         `
         document.getElementById("form").innerHTML = data;
    
    },
    error: function (req, err) {
      document.getElementById("table").innerHTML =`<div
      class="mb-3 bg-red-400 inline-flex w-full items-center rounded-lg bg-success-100 py-5 px-6 text-base text-success-700"
      role="alert">
      <span class="mr-2">
      <svg
      xmlns="http://www.w3.org/2000/svg"
      viewBox="0 0 24 24"
      fill="currentColor"
      class="h-5 w-5">
      <path
        fill-rule="evenodd"
        d="M12 2.25c-5.385 0-9.75 4.365-9.75 9.75s4.365 9.75 9.75 9.75 9.75-4.365 9.75-9.75S17.385 2.25 12 2.25zm-1.72 6.97a.75.75 0 10-1.06 1.06L10.94 12l-1.72 1.72a.75.75 0 101.06 1.06L12 13.06l1.72 1.72a.75.75 0 101.06-1.06L13.06 12l1.72-1.72a.75.75 0 10-1.06-1.06L12 10.94l-1.72-1.72z"
        clip-rule="evenodd" />
    </svg>
      </span>
      ${res}
    </div>
            `
            const myTimeout = setTimeout(function alert() {
              document.getElementById("table").style.display="none";
            }, 5000);
        console.log(err);
    },
    
    });
    }
    function signup() {
    
    var req = {
    
    name: document.getElementById("name").value,
    phone: document.getElementById("phone").value,
    email: document.getElementById("email").value,
    password: document.getElementById("password").value
    
    };
    
    $.ajax({
    type: "post",
    url: "http://localhost:3155/user/signup",
    
    headers: {
    
    },
      data: (req),
    success: function (res) {
    // alert("Done");
    console.log(res);
    document.getElementById("table").innerHTML =`<div
    class="mb-3 bg-green-400 inline-flex w-full items-center rounded-lg bg-success-100 py-5 px-6 text-base text-success-700"
    role="alert">
    <span class="mr-2">
      <svg
        xmlns="http://www.w3.org/2000/svg"
        viewBox="0 0 24 24"
        fill="currentColor"
        class="h-5 w-5">
        <path
          fill-rule="evenodd"
          d="M2.25 12c0-5.385 4.365-9.75 9.75-9.75s9.75 4.365 9.75 9.75-4.365 9.75-9.75 9.75S2.25 17.385 2.25 12zm13.36-1.814a.75.75 0 10-1.22-.872l-3.236 4.53L9.53 12.22a.75.75 0 00-1.06 1.06l2.25 2.25a.75.75 0 001.14-.094l3.75-5.25z"
          clip-rule="evenodd" />
      </svg>
    </span>
    ${res}
  </div>
          `
          const myTimeout = setTimeout(function alert() {
            document.getElementById("table").style.display="none";
            Vuser()
          }, 5000);


    
    // window.location.href = "/View/user/login.html";
    },
    error: function (req, err) {
    // alert("Failed");
    document.getElementById("table").innerHTML =`<div
    class="mb-3 bg-red-400 inline-flex w-full items-center rounded-lg bg-success-100 py-5 px-6 text-base text-success-700"
    role="alert">
    <span class="mr-2">
    <svg
    xmlns="http://www.w3.org/2000/svg"
    viewBox="0 0 24 24"
    fill="currentColor"
    class="h-5 w-5">
    <path
      fill-rule="evenodd"
      d="M12 2.25c-5.385 0-9.75 4.365-9.75 9.75s4.365 9.75 9.75 9.75 9.75-4.365 9.75-9.75S17.385 2.25 12 2.25zm-1.72 6.97a.75.75 0 10-1.06 1.06L10.94 12l-1.72 1.72a.75.75 0 101.06 1.06L12 13.06l1.72 1.72a.75.75 0 101.06-1.06L13.06 12l1.72-1.72a.75.75 0 10-1.06-1.06L12 10.94l-1.72-1.72z"
      clip-rule="evenodd" />
  </svg>
    </span>
    ${res}
  </div>
          `
          const myTimeout = setTimeout(function alert() {
            document.getElementById("table").style.display="none";
          }, 5000);
    console.log(err);
    },
    
    });
    }
    