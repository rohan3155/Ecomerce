function Vuser() {

    var req = {


    };


    $.ajax({
        type: "post",
        url: "http://localhost:3155/admin/view",

        headers: {

        },
          data: JSON.stringify(req),
        success: function (res) {

            console.log(res);
      

            document.getElementById("table").innerHTML = `
           
          
             <thead class=" py-6 text-gray-700  uppercase bg-gray-50 dark:bg-gray-700  dark:text-gray-400">
                      <tr>
        <th class=" text-xl  px-20">Name</th>
        <th class=" text-xl  px-20">Phone</th>
        <th class=" text-xl  px-20">Email</th>
        <th class=" text-xl  px-20">Password</th>
        <th class=" text-xl  px-20"></th>
        <th class=" text-xl  px-0"></th>
                      </tr>
                    </thead>
                    <tbody class="-mt-[8rem]"  id="table-body">
                    </tbody>
`
            let Ndata = "";
            // console.log(Object.keys(res[0]))
            res.forEach((value, index) => {
                Ndata += ` 
                      <tr class="bg-white text-white hover:text-black hover:bg-white font-sans border-b dark:bg-gray-800 dark:border-gray-700" >
                      <center>
                        <td id="name" class=" py-2 px-2 " >${value.name}</td>
                      <td id="phone" class=" " >${value.phone}</td>
                      <td id="email" class=" ">${value.email} </td>
                      <td id="password" class=" ">${value.password = "#####"} </td>
                      <td id="password" class=" btn "><center><button type="button" onclick="Edituser('${value._id}')" class="focus:outline-none text-white bg-green-700 hover:bg-green-800 focus:ring-4 focus:ring-green-300 font-medium rounded-lg text-sm px-5 py-2.5 mr-2 mb-2 dark:bg-green-600 dark:hover:bg-green-700 dark:focus:ring-green-800">Edit</button></center></td>
                      <td id="password" class=" btn "><center><button type="button" onclick="Udeleter('${value._id}')" class="focus:outline-none text-white bg-red-700 hover:bg-red-800 focus:ring-4 focus:ring-red-300 font-medium rounded-lg text-sm px-5 py-2.5 mr-2 mb-2 dark:bg-red-600 dark:hover:bg-red-700 dark:focus:ring-red-900">Delete</button></center></td>
                      </center>
                      </tr>
                    
                `
               
            });

            document.getElementById("table-body").innerHTML = Ndata;
        },
        error: function (req, err) {
            alert("Failed");
            console.log(err);
        },

    });
}
function Edituser(_id) {
console.log(_id)
const filter = {
  _id : _id
}

//view user by id
$.ajax({
  type: "post",
  url: "http://localhost:3155/admin/view",
  data: JSON.stringify(filter),
  contentType: "application/json",
  headers:{
    
  },
  success: function (res) {
    let _id = res[0]._id
    let name = res[0].name
    let email = res[0].email
    let phone = res[0].phone
    let password = res[0].password
console.log(name)
    

        document.getElementById("table").innerHTML = ` 
            <div class="container">
        <center>
          <h1 class="text-4xl text-[#0f172a] pt-6 ">Edit Details</h1>
         
            <div id="form">
              </div>
            <button type="button" onclick="Uupdater()" class="px-[8rem] py-3 text-white rounded-2xl mt-4   bg-gradient-to-r from-green-400 to-blue-500 hover:from-pink-500 hover:to-yellow-500 " onclick="signup()">
              Submit</button>
           
          </form>
        </center>
        </div>`


        let data = "";
          
           
             
              
               data = ` 
                  
             <div class="name mt-4">
             <input type="text" name="name" id="id" visibility: hidden   placeholder="Enter Your Name Here"
               class="shadow appearance-none border rounded w-[30%] py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline ">
           </div>
           <label for="name" class=" text-2xl text-[black]">Name</label> <br>
           <input type="text" name="name" id="name"   placeholder="Enter Your Name Here"
             class="shadow appearance-none border rounded w-[30%] py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline ">
         </div>
         <div class="phone mt-4">
           <label for="phone" class=" text-2xl text-[black]">Phone</label> <br>
           <input type="text" name="phone" id="phone"  placeholder="Enter Your Phone Number Here"
             class="shadow appearance-none border rounded w-[30%] py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline">
         </div>
         <div class="email mt-4">
           <label for="email" class=" text-2xl text-[black]">Email</label> <br>
           <input type="email" name="email" id="email"  placeholder="Enter Your email Here"
             class="shadow appearance-none border rounded w-[30%] py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline">
         </div>
         <div class="password mt-4">
           <label for="password" class=" text-2xl text-[black]">Password</label> <br>
           <input type="password" name="password"  id="password" placeholder="Enter Your password Here"
             class="shadow appearance-none border rounded w-[30%] py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline">
         </div>
             `
             document.getElementById("form").innerHTML = data;
             
             document.getElementById("id").value= _id
             document.getElementById("name").value= name
        document.getElementById("phone").value = phone
        document.getElementById("email").value= email
        document.getElementById("password").value = password
  }

})

}

function Uupdater() {
  var req = {
    filter:
    {
      _id: document.getElementById("id").value,
    },
    data:
    {
      name: document.getElementById("name").value,
  phone: document.getElementById("phone").value,
  email: document.getElementById("email").value,
  password: document.getElementById("password").value
    }
  
  
  
  };
  
  $.ajax({
  type: "post",
  url: "http://localhost:3155/admin/update",
  
  headers: {
  
  },
    data: JSON.stringify(req),
  success: function (res) {
  // alert("Done");
  console.log(res);
  // window.location.href = "/View/user/login.html";
  },
  error: function (req, err) {
  // alert("Failed");
  console.log(err);
  },
  
  });
  }

  function Udeleter(_id) {
    console.log(_id)
    var req = {
      filter:
      {
        _id:_id
      }
     
    
    
    
    };
    
    $.ajax({
    type: "post",
    url: "http://localhost:3155/admin/delete",
    
    headers: {
    
    },
      data: JSON.stringify(req),
    success: function (res) {
    console.log(res);
    Vuser();
    },
    error: function (req, err) {
    
    console.log(err);
    },
    
    });
    }
function Vproducts() {

    var req = {


    };


    $.ajax({
        type: "post",
        url: "http://localhost:3155/admin/Pview",

        headers: {

        },
          data: JSON.stringify(req),
        success: function (res) {

            console.log(res);


            document.getElementById("table").innerHTML = ` <thead class=" py-6 text-gray-700  uppercase bg-gray-50 dark:bg-gray-700  dark:text-gray-400">
              <tr>
<th class=" text-xl  ">productId</th>
<th class=" text-xl  ">name</th>
<th class=" text-xl  ">featuredImage</th>
<th class=" text-xl  ">price</th>
<th class=" text-xl  ">salePrice</th>
<th class=" text-xl  ">description</th>
<th class=" text-xl  ">stock</th>
<th class=" text-xl  ">category</th>
<th class=" text-xl  "></th>
<th class=" text-xl  "></th>

              </tr>
            </thead>
            <tbody class="-mt-[8rem]"  id="table-body">
            </tbody>
`
            let Ndata = "";
            // console.log(Object.keys(res[0]))
            res.forEach((value, index) => {
                Ndata += ` 
              <tr class="bg-white text-white hover:text-black hover:bg-white font-sans border-b dark:bg-gray-800 dark:border-gray-700" >
              <center>
                <td id="name" class=" py-2 "><center>${value.productId} <br> </center></td>
                <td id="name" class=" py-2 "><center>${value.name} <br> </center></td>
                <td id="name" class=" py-2 "><center>${value.featuredImage} <br> </center></td>
                <td id="name" class=" py-2 "><center>${value.price} <br> </center></td>
                <td id="name" class=" py-2 "><center>${value.salePrice} <br> </center></td>
                <td id="name" class=" py-2 "><center>${value.description} <br> </center></td>
                <td id="name" class=" py-2 "><center>${value.stock} <br> </center></td>
                <td id="name" class=" py-2 "><center>${value.categoryId.category}<br> </center></td>
                <td id="password" class=" btn "><center><button type="button" onclick="EditProducts('${value._id}')" class="focus:outline-none text-white bg-green-700 hover:bg-green-800 focus:ring-4 focus:ring-green-300 font-medium rounded-lg text-sm px-5 py-2.5 mr-2 mb-2 dark:bg-green-600 dark:hover:bg-green-700 dark:focus:ring-green-800">Edit</button></center></td>
                <td id="password" class=" btn "><center><button type="button" onclick="Pdeleter('${value._id}')" class="focus:outline-none text-white bg-red-700 hover:bg-red-800 focus:ring-4 focus:ring-red-300 font-medium rounded-lg text-sm px-5 py-2.5 mr-2 mb-2 dark:bg-red-600 dark:hover:bg-red-700 dark:focus:ring-red-900">Delete</button></center></td>

              </center>
              </tr>
            
        `
            });

            document.getElementById("table-body").innerHTML = Ndata;
        },
        error: function (req, err) {
            alert("Failed");
            console.log(err);
        },

    });
}

function EditProducts(_id) {
  console.log(_id)
  const filter = {
    _id:_id
  }
  
  //view products by id
  $.ajax({
    type: "post",
    url: "http://localhost:3155/admin/Pview",
    data: JSON.stringify(filter),
    contentType: "application/json",
    headers:{
      
    },
    success: function (res) {
      let id = res[0]._id
      let productId = res[0].productId
      let name = res[0].name
      let featuredImage = res[0].featuredImage
      let price = res[0].price
      let salePrice = res[0].salePrice
      let description = res[0].description
      let stock = res[0].stock
      let category = res[0].categoryId.category
  console.log(name)
      
  
          document.getElementById("table").innerHTML = ` 
              <div class="container">
          <center>
            <h1 class="text-4xl text-[#0f172a] pt-6 ">Edit Details</h1>
           
              <div id="form">
                </div>
              <button type="button" onclick="Pupdater()" class="px-[8rem] py-3 text-white rounded-2xl mt-4   bg-gradient-to-r from-green-400 to-blue-500 hover:from-pink-500 hover:to-yellow-500 " onclick="signup()">
                Submit</button>
             
            </form>
          </center>
          </div>`
  
  
          let data = "";
            
             
               
                
                 data =   `
   
    <div class="container">
<center>
  <h1 class="text-4xl text-[#0f172a] pt-6 ">Add Product</h1>
  <div class="productId mt-4">
      <input type="text" name="ProductId" id="id" 
        class="shadow appearance-none visibility: hidden border rounded w-[30%] py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline ">
    </div>
    <div class="productId mt-4">
      <label for="productId" class=" text-2xl text-[black]">productId</label> <br>
      <input type="text" name="ProductId" id="productId" 
        class="shadow appearance-none border rounded w-[30%] py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline ">
    </div>
    <div class="name mt-4">
        <label for="name" class=" text-2xl text-[black]">Product Name</label> <br>
        <input type="text" name="name" id="name" 
          class="shadow appearance-none border rounded w-[30%] py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline">
      </div>
      <div class="featuredImage mt-4">
        <label for="featuredImage" class=" text-2xl text-[black]">FeaturedImage</label> <br>
        <input type="text" name="featuredImage" id="featuredImage" 
          class="shadow appearance-none border rounded w-[30%] py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline ">
      </div>
      <div class="price mt-4">
        <label for="price" class=" text-2xl text-[black]">Price</label> <br>
        <input type="text" name="price" id="price" 
          class="shadow appearance-none border rounded w-[30%] py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline">
      </div>
      <div class="salePrice mt-4">
        <label for="salePrice" class=" text-2xl text-[black]">SalePrice</label> <br>
        <input type="text" name="salePrice" id="salePrice" 
          class="shadow appearance-none border rounded w-[30%] py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline ">
      </div>
      <div class="stock mt-4">
        <label for="stock" class=" text-2xl text-[black]">Stock</label> <br>
        <input type="text" name="stock" id="stock"
          class="shadow appearance-none border rounded w-[30%] py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline ">
      </div>
      <div class="description mt-4">
        <label for="description" class=" text-2xl text-[black]">Description</label> <br>
        <input type="text" name="description" id="description" 
          class="shadow appearance-none border rounded w-[40%] py-8 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline ">
      </div>
     
      <div class="categoryId mt-4">
        <label for="categoryId" class=" text-2xl text-[black]">CategoryId</label> <br>
        <input type="text" name="categoryId" id="categoryId" 
          class="shadow appearance-none border rounded w-[30%] py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline ">
      </div>
     
    
  
</center>
</div>


`

               
               document.getElementById("form").innerHTML = data;
               
               document.getElementById("id").value= id
               document.getElementById("productId").value= productId
               document.getElementById("name").value= name
          document.getElementById("featuredImage").value = featuredImage
          document.getElementById("price").value= price
          document.getElementById("salePrice").value = salePrice
          document.getElementById("description").value = description
          document.getElementById("stock").value = stock
          document.getElementById("categoryId").value = category
    }
  
  })
  
  }


  function Pupdater() {
    var req = {
      filter:
      {
        _id: document.getElementById("id").value,
      },
      data:
      {
        productId :document.getElementById("productId").value,
        name:document.getElementById("name").value ,
        featuredImage:document.getElementById("featuredImage").value,
        price:document.getElementById("price").value,
        salePrice:document.getElementById("salePrice").value ,
        description:document.getElementById("description").value,
        stock:document.getElementById("stock").value ,
        category:document.getElementById("categoryId").value
      }
    
    
    
    };
    
    $.ajax({
    type: "post",
    url: "http://localhost:3155/admin/Pupdate",
    
    headers: {
    
    },
      data: JSON.stringify(req),
    success: function (res) {
    // alert("Done");
    console.log(res);
    // window.location.href = "/View/user/login.html";
    },
    error: function (req, err) {
    // alert("Failed");
    console.log(err);
    },
    
    });
    }
    function Pdeleter(_id) {
      console.log(_id)
      var req = {
        filter:
        {
          _id:_id
        }
       
      
      
      
      };
      
      $.ajax({
      type: "post",
      url: "http://localhost:3155/admin/Pdelete",
      
      headers: {
      
      },
        data: JSON.stringify(req),
      success: function (res) {
      console.log(res);
      Vproducts();
      },
      error: function (req, err) {
      
      console.log(err);
      },
      
      });
      }
     
function Vorders() {

    var req = {


    };


    $.ajax({
        type: "post",
        url: "http://localhost:3155/admin/orders",

        headers: {

        },
          data: JSON.stringify(req),
        success: function (res) {

            console.log(res);


            document.getElementById("table").innerHTML = ` <thead class=" py-6 text-gray-700  uppercase bg-gray-50 dark:bg-gray-700  dark:text-gray-400">
              <tr>
<th class=" text-l py-3"><center>UserName</center></th>
<th class=" text-l "><center>UserPhone</center></th>
<th class=" text-l "><center>UserEmail</center></th>
<th class=" text-l ">Productname</th>
<th class=" text-l ">BuyingPrice</th>
<th class=" text-l ">SellingPrice</th>
<th class=" text-l ">InStock</th>
<th class=" text-l ">quantity</th>
              </tr>
            </thead>
            <tbody class="-mt-[8rem]"  id="table-body">
            </tbody>
`
            let Ndata = "";
            console.log(Object.keys(res[0]))
            res.forEach((value, index) => {
                Ndata += ` 
              <tr class="bg-white text-white hover:text-black hover:bg-white font-sans border-b dark:bg-gray-800 dark:border-gray-700" >
              <center>
                <td id="name" class=" py-2 "><center>${value.userId.name} <br> </center></td>
                <td id="name" class=" py-2 "><center>${value.userId.phone} <br> </center></td>
                <td id="name" class=" py-2 "><center>${value.userId.email} <br> </center></td>
              <td id="phone" class=" "><center>${value.productId.name} <br> </center></td>
              <td id="phone" class=" "><center>${value.productId.price} <br> </center></td>
              <td id="email" class=" "><center>${value.productId.salePrice} <br> </center></td>
              <td id="email" class=" "><center>${value.productId.stock} <br> </center></td>
              <td id="email" class=" "><center>${value.quantity} <br> </center></td>
             
              </center>
              </tr>
            
        `
            });

            document.getElementById("table-body").innerHTML = Ndata;
        },
        error: function (req, err) {
            alert("Failed");
            console.log(err);
        },

    });
}

function Vcategories() {

    var req = {


    };


    $.ajax({
        type: "post",
        url: "http://localhost:3155/admin/Cview",

        headers: {

        },
          data: JSON.stringify(req),
        success: function (res) {

            console.log(res);


            document.getElementById("table").innerHTML = ` <thead class=" py-6 text-gray-700  uppercase bg-gray-50 dark:bg-gray-700  dark:text-gray-400">
              <tr>
<th class=" text-xl  px-24"><center>Categories</center></th>
<th class=" text-xl  px-24"><center></center></th>
<th class=" text-xl  px-24"><center></center></th>

              </tr>
            </thead>
            <tbody class="-mt-[8rem]"  id="table-body">
            </tbody>
`
            let Ndata = "";
            console.log(Object.keys(res[0]))
            res.forEach((value, index) => {
                Ndata += ` 
              <tr class="bg-white text-white hover:text-black hover:bg-white font-sans border-b dark:bg-gray-800 dark:border-gray-700" >
              <center>
                <td id="name" class=" py-2 " id="categories"><center>${value.category}   <br> </center></td>
                <td id="password" class=" "><center><button type="button" onclick="editCategory('${value._id}')" class="focus:outline-none text-white bg-green-700 hover:bg-green-800 focus:ring-4 focus:ring-green-300 font-medium rounded-lg text-sm px-5 py-2.5 mr-2 mb-2 dark:bg-green-600 dark:hover:bg-green-700 dark:focus:ring-green-800">Edit</button></center></td>
                <td id="password" class=" "><center><button type="button" onclick="Cdeleter('${value._id}')" class="focus:outline-none text-white bg-red-700 hover:bg-red-800 focus:ring-4 focus:ring-red-300 font-medium rounded-lg text-sm px-5 py-2.5 mr-2 mb-2 dark:bg-red-600 dark:hover:bg-red-700 dark:focus:ring-red-900">Delete</button></center></td>

              </center>
              </tr>
            
        `
            });

            document.getElementById("table-body").innerHTML = Ndata;
        },
        error: function (req, err) {
            alert("Failed");
            console.log(err);
        },

    });
}
function editCategory(_id) {
  console.log(_id)
  const filter = {
    _id : _id
  }
  
  //view user by id
  $.ajax({
    type: "post",
    url: "http://localhost:3155/admin/Cview",
    data: JSON.stringify(filter),
    contentType: "application/json",
    headers:{
      
    },
    success: function (res) {
      let id = res[0]._id
      let category = res[0].category
     
  console.log(category)
      
  
          document.getElementById("table").innerHTML = ` 
              <div class="container">
          <center>
            <h1 class="text-4xl text-[#0f172a] pt-6 ">Edit Details</h1>
           
              <div id="form">
                </div>
              <button type="button" onclick="Cupdater()" class="px-[8rem] py-3 text-white rounded-2xl mt-4   bg-gradient-to-r from-green-400 to-blue-500 hover:from-pink-500 hover:to-yellow-500 " onclick="signup()">
                Submit</button>
             
            </form>
          </center>
          </div>`
  
  
          let data = "";
            
             
               
                
                 data = ` 
                    
               <div class="name mt-4">
               <div class="id mt-4">
                 <input type="text" name="id" id="id" 
                 class="shadow appearance-none border visibility: hidden rounded w-[30%] py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline ">
             </div>
               <div class="categoryId mt-4">
               <label for="categoryId" class=" text-2xl text-[black]">Category</label> <br>
               <input type="text" name="category" id="category" 
                 class="shadow appearance-none border rounded w-[30%] py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline ">
             </div>
           </div>
               `
               document.getElementById("form").innerHTML = data;
               
               document.getElementById("id").value= id
               document.getElementById("category").value= category
          
    }
  
  })
  
  }
  
  function Cupdater() {
    var req = {
      filter:
      {
        _id: document.getElementById("id").value,
      },
      data:
      {
         category:document.getElementById("category").value
      }
    
    
    
    };
    
    $.ajax({
    type: "post",
    url: "http://localhost:3155/admin/Cupdate",
    
    headers: {
    
    },
      data: JSON.stringify(req),
    success: function (res) {
    console.log(res);
    },
    error: function (req, err) {
    
    console.log(err);
    },
    
    });
    }
    function Cdeleter(_id) {
      console.log(_id)
      var req = {
        filter:
        {
          _id:_id
        }
       
      
      
      
      };
      
      $.ajax({
      type: "post",
      url: "http://localhost:3155/admin/Cdelete",
      
      headers: {
      
      },
        data: JSON.stringify(req),
      success: function (res) {
      console.log(res);
      
      Vcategories();
      },
      error: function (req, err) {
      
      console.log(err);
      },
      
      });
      }
     
function Adduser() {

var req = {


};
$.ajax({
type: "post",
url: "http://localhost:3155/admin/create",

headers: {

},
  data: JSON.stringify(req),
success: function (res) {

    console.log(res);


    document.getElementById("table").innerHTML = `
    <div class="container">
<center>
  <h1 class="text-4xl text-[#0f172a] pt-6 ">Create Account</h1>
  
    <div class="name mt-4">
      <label for="name" class=" text-2xl text-[black]">Name</label> <br>
      <input type="text" name="name" id="name" placeholder="Enter Your Name Here"
        class="shadow appearance-none border rounded w-[30%] py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline ">
    </div>
    <div class="phone mt-4">
      <label for="phone" class=" text-2xl text-[black]">Phone</label> <br>
      <input type="text" name="phone" id="phone" placeholder="Enter Your Phone Number Here"
        class="shadow appearance-none border rounded w-[30%] py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline">
    </div>
    <div class="email mt-4">
      <label for="email" class=" text-2xl text-[black]">Email</label> <br>
      <input type="email" name="email" id="email" placeholder="Enter Your email Here"
        class="shadow appearance-none border rounded w-[30%] py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline">
    </div>
    <div class="password mt-4">
      <label for="password" class=" text-2xl text-[black]">Password</label> <br>
      <input type="password" name="password" id="password" placeholder="Enter Your password Here"
        class="shadow appearance-none border rounded w-[30%] py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline">
    </div>
    <button type="button" class="px-[8rem] py-3 text-white rounded-2xl mt-4   bg-gradient-to-r from-green-400 to-blue-500 hover:from-pink-500 hover:to-yellow-500 " onclick="signup()">
      Submit</button>
   
  
</center>
</div>
   


`

},
error: function (req, err) {
    alert("Failed");
    console.log(err);
},

});
}
function signup() {

var req = {

name: document.getElementById("name").value,
phone: document.getElementById("phone").value,
email: document.getElementById("email").value,
password: document.getElementById("password").value

};

$.ajax({
type: "post",
url: "http://localhost:3155/user/signup",

headers: {

},
  data: JSON.stringify(req),
success: function (res) {
// alert("Done");
console.log(res);
document.getElementById("table").innerHTML =`
      <div class="p-4 mb-4 text-sm text-green-800 rounded-lg bg-green-50 dark:bg-gray-800 dark:text-green-400" role="alert">
  <span class="font-medium">${res}</span> 
</div>
      `

// window.location.href = "/View/user/login.html";
},
error: function (req, err) {
// alert("Failed");
console.log(err);
},

});
}
function AddProducts() {

var req = {


};
$.ajax({
type: "post",
url: "http://localhost:3155/admin/Pcreate",

headers: {

},
  data: JSON.stringify(req),
success: function (res) {

    console.log(res);


    document.getElementById("table").innerHTML = `
   
    <div class="container">
<center>
  <h1 class="text-4xl text-[#0f172a] pt-6 ">Add Product</h1>
  
    <div class="productId mt-4">
      <label for="productId" class=" text-2xl text-[black]">productId</label> <br>
      <input type="text" name="ProductId" id="productId" 
        class="shadow appearance-none border rounded w-[30%] py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline ">
    </div>
    <div class="name mt-4">
        <label for="name" class=" text-2xl text-[black]">Product Name</label> <br>
        <input type="text" name="name" id="name" 
          class="shadow appearance-none border rounded w-[30%] py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline">
      </div>
      <div class="featuredImage mt-4">
        <label for="featuredImage" class=" text-2xl text-[black]">FeaturedImage</label> <br>
        <input type="text" name="featuredImage" id="featuredImage" 
          class="shadow appearance-none border rounded w-[30%] py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline ">
      </div>
      <div class="price mt-4">
        <label for="price" class=" text-2xl text-[black]">Price</label> <br>
        <input type="text" name="price" id="price" 
          class="shadow appearance-none border rounded w-[30%] py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline">
      </div>
      <div class="salePrice mt-4">
        <label for="salePrice" class=" text-2xl text-[black]">SalePrice</label> <br>
        <input type="text" name="salePrice" id="salePrice" 
          class="shadow appearance-none border rounded w-[30%] py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline ">
      </div>
      <div class="stock mt-4">
        <label for="stock" class=" text-2xl text-[black]">Stock</label> <br>
        <input type="text" name="stock" id="stock"
          class="shadow appearance-none border rounded w-[30%] py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline ">
      </div>
      <div class="description mt-4">
        <label for="description" class=" text-2xl text-[black]">Description</label> <br>
        <input type="text" name="description" id="description" 
          class="shadow appearance-none border rounded w-[40%] py-8 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline ">
      </div>
     
      <div class="categoryId mt-4">
        <label for="categoryId" class=" text-2xl text-[black]">CategoryId</label> <br>
        <input type="text" name="categoryId" id="categoryId" 
          class="shadow appearance-none border rounded w-[30%] py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline ">
      </div>
     
    <button type="button" class="px-[8rem] py-3 text-white rounded-2xl mt-4   bg-gradient-to-r from-green-400 to-blue-500 hover:from-pink-500 hover:to-yellow-500 " onclick="prodadd()">
      Submit</button>
  
</center>
</div>


`
    
},
error: function (req, err) {
    alert("Failed");
    console.log(err);
},

});
}
function prodadd() {

var req = {

productId: document.getElementById("productId").value,
name: document.getElementById("name").value,
featuredImage: document.getElementById("featuredImage").value,
price: document.getElementById("price").value,
salePrice: document.getElementById("salePrice").value,
description: document.getElementById("description").value,
stock: document.getElementById("stock").value,
categoryId: document.getElementById("categoryId").value,
};

$.ajax({
type: "post",
url: "http://localhost:3155/admin/Pcreate",

headers: {

},
  data: JSON.stringify(req),
success: function (res) {
// alert("Done");
console.log(res);
document.getElementById("table").innerHTML =`
      <div class="p-4 mb-4 text-sm text-green-800 rounded-lg bg-green-50 dark:bg-gray-800 dark:text-green-400" role="alert">
  <span class="font-medium">${res}</span> 
</div>
      `
// window.location.href = "/View/user/login.html";
},
error: function (req, err) {
// alert("Failed");
console.log(err);
},

});
}

function AddCategory() {

var req = {


};
$.ajax({
type: "post",
url: "http://localhost:3155/admin/Ccreate",

headers: {

},
  data: JSON.stringify(req),
success: function (res) {

    console.log(res);


    document.getElementById("table").innerHTML = `
   
    <div class="container">
<center>
  <h1 class="text-4xl text-[#0f172a] pt-6 ">Add Category</h1>
  
      <div class="categoryId mt-4">
        <label for="categoryId" class=" text-2xl text-[black]">Category</label> <br>
        <input type="text" name="category" id="category" 
          class="shadow appearance-none border rounded w-[30%] py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline ">
      </div>
     
    <button type="button" class="px-[8rem] py-3 text-white rounded-2xl mt-4   bg-gradient-to-r from-green-400 to-blue-500 hover:from-pink-500 hover:to-yellow-500 " onclick="catadd()">
      Submit</button>

</center>
</div>


`
    
},
error: function (req, err) {
    alert("Failed");
    console.log(err);
},

});
}
function catadd() {

var req = {

category: document.getElementById("category").value,
};

$.ajax({
type: "post",
url: "http://localhost:3155/admin/Ccreate",

headers: {

},
  data: JSON.stringify(req),
success: function (res) {
// alert("Done");
console.log(res);
document.getElementById("table").innerHTML =`
      <div class="p-4 mb-4 text-sm text-green-800 rounded-lg bg-green-50 dark:bg-gray-800 dark:text-green-400" role="alert">
  <span class="font-medium">${res}</span> 
</div>
      `
      
// window.location.href = "/View/user/login.html";
},
error: function (req, err) {
// alert("Failed");
console.log(err);
},

});
}


