

function Vproducts() {

  var req = {


  };


  $.ajax({
    type: "post",
    url: "http://localhost:3155/admin/Pview",

    headers: {

    },
    data: (req),
    success: function (res) {

      console.log(res);


      document.getElementById("table").innerHTML = ` 

            
            <thead class="">
              <tr>
              
            <th
            class="whitespace-nowrap px-4 py-2 text-left font-medium text-gray-900"
          >name</th>
        
        <th
        class="whitespace-nowrap px-4 py-2 text-left font-medium text-gray-900"
      >price</th>
      <th
      class="whitespace-nowrap px-4 py-2 text-left font-medium text-gray-900"
    >salePrice</th>
    <th
    class="whitespace-nowrap px-4 py-2 text-left font-medium text-gray-900"
  >description</th>
  <th
  class="whitespace-nowrap px-4 py-2 text-left font-medium text-gray-900"
>stock</th>

<th
class="whitespace-nowrap px-4 py-2 text-left font-medium text-gray-900">category</th>
<th
class="whitespace-nowrap px-4 py-2 text-left font-medium text-gray-900"
></th>


              </tr>
            </thead>
            <tbody class="divide-y divide-gray-200"  id="table-body">
            </tbody>
`
      let Ndata = "";
      // console.log(Object.keys(res[0]))
      res.forEach((value, index) => {
        Ndata += ` 
              <tr class=  font-sans border-b dark:bg-gray-800 dark:border-gray-700" >
              <center>
                            
               <td id="name" class="whitespace-nowrap px-4 py-2 text-gray-700">${value.name} <br></td>
                <td id="name" class="whitespace-nowrap px-4 py-2 text-gray-700">${value.price} <br></td>
                <td id="name" class="whitespace-nowrap px-4 py-2 text-gray-700 ">${value.salePrice} <br></td>
                <td id="name" class="whitespace-nowrap px-4 py-2 text-gray-700 ">${value.description} <br></td>
                <td id="name" class="whitespace-nowrap px-4 py-2 text-gray-700">${value.stock} <br></td>
                <td id="name" class="whitespace-nowrap px-4 py-2 text-gray-700 ">${value.categoryId.category}<br></td>
                <td class="whitespace-nowrap px-4 py-2">
                <span
                class="inline-flex divide-x overflow-hidden rounded-md border bg-white shadow-sm"
              >
              <button
                onclick="addimages('${value._id}')"
                  class="inline-block p-3 text-gray-700 hover:bg-gray-50 focus:relative"
                  title="Add Images"
                >
                <i class="fa-solid fa-image"></i>
                </button>
                <button
                onclick="EditProducts('${value._id}');viewcat2()"
                  class="inline-block p-3 text-gray-700 hover:bg-gray-50 focus:relative"
                  title="Edit Product"
                >
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    fill="none"
                    viewBox="0 0 24 24"
                    stroke-width="1.5"
                    stroke="currentColor"
                    class="h-4 w-4"
                  >
                    <path
                      stroke-linecap="round"
                      stroke-linejoin="round"
                      d="M16.862 4.487l1.687-1.688a1.875 1.875 0 112.652 2.652L10.582 16.07a4.5 4.5 0 01-1.897 1.13L6 18l.8-2.685a4.5 4.5 0 011.13-1.897l8.932-8.931zm0 0L19.5 7.125M18 14v4.75A2.25 2.25 0 0115.75 21H5.25A2.25 2.25 0 013 18.75V8.25A2.25 2.25 0 015.25 6H10"
                    />
                  </svg>
                </button>
              
                <button
                onclick="Pdeleter('${value._id}')"
                  class="inline-block p-3 text-gray-700 hover:bg-gray-50 focus:relative"
                  title="Delete Product"
                >
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    fill="none"
                    viewBox="0 0 24 24"
                    stroke-width="1.5"
                    stroke="currentColor"
                    class="h-4 w-4"
                  >
                    <path
                      stroke-linecap="round"
                      stroke-linejoin="round"
                      d="M14.74 9l-.346 9m-4.788 0L9.26 9m9.968-3.21c.342.052.682.107 1.022.166m-1.022-.165L18.16 19.673a2.25 2.25 0 01-2.244 2.077H8.084a2.25 2.25 0 01-2.244-2.077L4.772 5.79m14.456 0a48.108 48.108 0 00-3.478-.397m-12 .562c.34-.059.68-.114 1.022-.165m0 0a48.11 48.11 0 013.478-.397m7.5 0v-.916c0-1.18-.91-2.164-2.09-2.201a51.964 51.964 0 00-3.32 0c-1.18.037-2.09 1.022-2.09 2.201v.916m7.5 0a48.667 48.667 0 00-7.5 0"
                    />
                  </svg>
                </button>
              </span>
              
                </td>
              </center>
              </tr>
            
        `
      });

      document.getElementById("table-body").innerHTML = Ndata;
    },
    error: function (req, err) {
      alert("Failed");
      console.log(err);
    },

  });
}

function addimages(_id)
{


  document.getElementById("table").innerHTML = ` 
              <div class="container">
          <center>
            <h1 class="text-4xl text-[#0f172a] pt-6 ">Add Images</h1>
           
              <div id="form">
                </div>
            
            </form>
          </center>
          </div>`


      let data = "";




      data = `
   
    <div class="container">
<center>
  <div class="w-full max-w-lg">
  <form action="http://localhost:3155/admin/addimage" method="post"  enctype="multipart/form-data" class="bg-white shadow-md rounded px-8 pt-6 pb-8 mb-4" name="addimage">
  <div class="productId mb-4">
      <input type="text" name="ProductId" id="id" value="${_id}" 
        class="shadow appearance-none visibility: hidden border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline ">
    </div>
      <div class="featuredImage mt-4">
        <label for="featuredImage" class="block text-gray-700 text-sm font-bold mb-2"> Add Image</label> <br>
        <input type="file" name="featuredImage" id="featuredImage" 
         class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline">
      </div>
      <button type="submit"  class="px-[8rem] py-3 text-white rounded-2xl mt-4   bg-gradient-to-r from-green-400 to-blue-500 hover:from-pink-500 hover:to-yellow-500 ">
      Submit</button>
   
      </form>
</div>


     
    
  
</center>
</div>


`


      document.getElementById("form").innerHTML = data;
      
}
function EditProducts(_id) {
  console.log(_id)
  const filter = {
    _id: _id
  }

  //view products by id
  $.ajax({
    type: "post",
    url: "http://localhost:3155/admin/Pview",
    data: JSON.stringify(filter),
    contentType: "application/json",
    headers: {

    },
    success: function (res) {
      let id = res[0]._id
      let productId = res[0].productId
      let name = res[0].name
      // let featuredImage = res[0].featuredImage
      let price = res[0].price
      let salePrice = res[0].salePrice
      let description = res[0].description
      let stock = res[0].stock
      let category = res[0].categoryId.category
      console.log(name)


      document.getElementById("table").innerHTML = ` 
              <div class="container">
          <center>
            <h1 class="text-4xl text-[#0f172a] pt-6 ">Edit Details</h1>
           
              <div id="form">
                </div>
              <button type="button" onclick="Pupdater()" class="px-[8rem] py-3 text-white rounded-2xl mt-4   bg-gradient-to-r from-green-400 to-blue-500 hover:from-pink-500 hover:to-yellow-500 " onclick="signup()">
                Submit</button>
             
            </form>
          </center>
          </div>`


      let data = "";




      data = `
   
    <div class="container">
<center>
  <div class="w-full max-w-lg">
  <form class="bg-white shadow-md rounded px-8 pt-6 pb-8 mb-4">
  <div class="productId mb-4">
      <input type="text" name="ProductId" id="id" 
        class="shadow appearance-none visibility: hidden border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline ">
    </div>
    
    <div class="name mb-4">
        <label for="name" class="block text-gray-700 text-sm font-bold mb-2">Product Name</label> <br>
        <input type="text" name="name" id="name" 
          class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline">
      </div>
     
      <div class="price mb-4">
        <label for="price" class="block text-gray-700 text-sm font-bold mb-2">Price</label> <br>
        <input type="text" name="price" id="price" 
          class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline">
      </div>
      <div class="salePrice mb-4">
        <label for="salePrice" class="block text-gray-700 text-sm font-bold mb-2">SalePrice</label> <br>
        <input type="text" name="salePrice" id="salePrice" 
         class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline">
      </div>
      <div class="stock mb-4">
        <label for="stock" class="block text-gray-700 text-sm font-bold mb-2">Stock</label> <br>
        <input type="text" name="stock" id="stock"
         class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline">
      </div>
      <div class="description mb-4">
        <label for="description" class="block text-gray-700 text-sm font-bold mb-2">Description</label> <br>
        <input type="text" name="description" id="description" 
          class="shadow appearance-none border rounded w-full py-8 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline ">
      </div>
     
      <div class="categoryId mb-4">
      <label for="categoryId" class="block text-gray-700 text-sm font-bold mb-2">Category</label> <br>
      <select id="options22a"  class="bg-white border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 dark:bg-white dark:border-gray-600 dark:placeholder-gray-400 dark:text-gray-700 dark:focus:ring-blue-500 dark:focus:border-blue-500">
      <option selected id="selected"></option>
    </select>
    
    </div>
      </form>
</div>


     
    
  
</center>
</div>


`


      document.getElementById("form").innerHTML = data;

      document.getElementById("id").value = id
      document.getElementById("name").value = name
      // document.getElementById("featuredImage").value = featuredImage
      document.getElementById("price").value = price
      document.getElementById("salePrice").value = salePrice
      document.getElementById("description").value = description
      document.getElementById("stock").value = stock
      document.getElementById("selected").value = category
    }

  })

}


function Pupdater() {
  var req = {
    filter:
    {
      _id: document.getElementById("id").value,
    },
    data:
    {
      name: document.getElementById("name").value,
      // featuredImage: document.getElementById("featuredImage").value,
      price: document.getElementById("price").value,
      salePrice: document.getElementById("salePrice").value,
      description: document.getElementById("description").value,
      stock: document.getElementById("stock").value,
      category:document.getElementById("selected").value
    }



  };

  $.ajax({
    type: "post",
    url: "http://localhost:3155/admin/Pupdate",

    headers: {

    },
    data: (req),
    success: function (res) {
      // console.log(res);
      setTimeout(() => {
        Vproducts()
      }, 1000);

    },
    error: function (req, err) {
      // alert("Failed");
      console.log(err);
    },

  });
}
function Pdeleter(_id) {
  console.log(_id)
  var req = {
    filter:
    {
      _id: _id
    }




  };

  $.ajax({
    type: "post",
    url: "http://localhost:3155/admin/Pdelete",

    headers: {

    },
    data: (req),
    success: function (res) {
      console.log(res);
      Vproducts();
    },
    error: function (req, err) {

      console.log(err);
    },

  });
}

function AddProducts() {

  var req = {


  };
  $.ajax({
    type: "post",
    url: "http://localhost:3155/admin/Pcreate",

    headers: {

    },
    data: (req),
    success: function (res) {



      document.getElementById("table").innerHTML = ` 
            <div class="container">
        <center>
          <h1 class="text-4xl text-[#0f172a] pt-6 ">Edit Details</h1>
         
            <div id="form">
              </div>
            <button type="button" onclick="prodadd()" class="px-[8rem] py-3 text-white rounded-2xl mt-4   bg-gradient-to-r from-green-400 to-blue-500 hover:from-pink-500 hover:to-yellow-500 " onclick="signup()">
              Submit</button>
           
          </form>
        </center>
        </div>`


      let data = "";




      data = `
 
  <div class="container">
<center>
<div class="w-full max-w-lg">
<form class="bg-white shadow-md rounded px-8 pt-6 pb-8 mb-4">
<div class="productId mb-4">
    <input type="text" name="ProductId" id="id" 
      class="shadow appearance-none visibility: hidden border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline ">
  </div>
  <div class="name mb-4">
      <label for="name" class="block text-gray-700 text-sm font-bold mb-2">Product Name</label> <br>
      <input type="text" name="name" id="nameing" 
        class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline">
    </div>
    <div class="price mb-4">
      <label for="price" class="block text-gray-700 text-sm font-bold mb-2">Price</label> <br>
      <input type="text" name="price" id="price" 
        class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline">
    </div>
    <div class="salePrice mb-4">
      <label for="salePrice" class="block text-gray-700 text-sm font-bold mb-2">SalePrice</label> <br>
      <input type="text" name="salePrice" id="salePrice" 
       class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline">
    </div>
    <div class="stock mb-4">
      <label for="stock" class="block text-gray-700 text-sm font-bold mb-2">Stock</label> <br>
      <input type="text" name="stock" id="stock"
       class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline">
    </div>
    <div class="description mb-4">
      <label for="description" class="block text-gray-700 text-sm font-bold mb-2">Description</label> <br>
      <input type="text" name="description" id="description" 
        class="shadow appearance-none border rounded w-full py-8 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline ">
    </div>
    
   
    <div class="categoryId mb-4">
      <label for="categoryId" class="block text-gray-700 text-sm font-bold mb-2">Category</label> <br>
      <select id="options"  class="bg-white border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 dark:bg-white dark:border-gray-600 dark:placeholder-gray-400 dark:text-gray-700 dark:focus:ring-blue-500 dark:focus:border-blue-500">
      <option selected id="selected"></option>
    </select>

</div>
    </form>
</div>


   
  

</center>
</div>


`


      document.getElementById("form").innerHTML = data;

    },
    error: function (req, err) {
      alert("Failed");
      console.log(err);
    },

  });
}
function prodadd() {

  var req = {
    name: document.getElementById("nameing").value,
    price: document.getElementById("price").value,
    salePrice: document.getElementById("salePrice").value,
    description: document.getElementById("description").value,
    stock: document.getElementById("stock").value,
    categoryId: document.getElementById("options").value,
  };

  $.ajax({
    type: "post",
    url: "http://localhost:3155/admin/Pcreate",

    headers: {

    },
    data: (req),
    success: function (res) {
      // alert("Done");
      console.log(res);
      document.getElementById("table").innerHTML = `
              <div class="p-4 mb-4 text-sm text-green-800 rounded-lg bg-green-50 dark:bg-gray-800 dark:text-green-400" role="alert">
          <span class="font-medium">${res}</span> 
        </div>
              `
      // window.location.href = "/View/user/login.html";
    },
    error: function (req, err) {
      // alert("Failed");
      console.log(err);
    },

  });
}



function viewcat() {

  var req = {


  };


  $.ajax({
    type: "post",
    url: "http://localhost:3155/admin/Cview",

    headers: {

    },
    data: (req),
    success: function (res) {

      console.log(res);


      let Ndata = "";
      // console.log(Object.keys(res[0]))
      res.map((value, index) => {
        Ndata += ` 
                   <option value="${value._id}">${value.category}</option>
                   
              `
      })
      document.getElementById("options").innerHTML = Ndata;
      

    },
    error: function (req, err) {
      alert("Failed");
      console.log(err);
    },

  });
}

function viewcat2() {

  var req = {


  };


  $.ajax({
    type: "post",
    url: "http://localhost:3155/admin/Cview",
    // contentType: "application/json",
    headers: {

    },
    data: (req),
    success: function (res) {

      console.log(res);


      let Ndata = "";
      // console.log(Object.keys(res[0]))
      res.map((value, index) => {
        Ndata += ` 
                 <option value="${value._id}">${value.category}</option>
            `
      })
      setTimeout(() => {
            document.getElementById("options22a").innerHTML  = Ndata

      }, 1000)
      

    },
    error: function (req, err) {
      alert("Failed");
      console.log(err);
    },

  });
}