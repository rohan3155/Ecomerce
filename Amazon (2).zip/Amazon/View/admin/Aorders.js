function Vorders() {

    var req = {


    };


    $.ajax({
        type: "post",
        url: "http://localhost:3155/admin/orders",

        headers: {

        },
          data: JSON.stringify(req),
        success: function (res) {

            console.log(res);


            document.getElementById("table").innerHTML = ` <thead class="">
              <tr>
<th class=" whitespace-nowrap px-4 py-2 text-left font-medium text-gray-900"><center>CustomerName</center></th>
<th class="whitespace-nowrap px-4 py-2 text-left font-medium text-gray-900"><center>CustomerPhone</center></th>
<th class="whitespace-nowrap px-4 py-2 text-left font-medium text-gray-900 "><center>CustomerEmail</center></th>
<th class="whitespace-nowrap px-4 py-2 text-left font-medium text-gray-900 ">Productname</th>
<th class="whitespace-nowrap px-4 py-2 text-left font-medium text-gray-900 ">BuyingPrice</th>
<th class="whitespace-nowrap px-4 py-2 text-left font-medium text-gray-900 ">SellingPrice</th>
<th class="whitespace-nowrap px-4 py-2 text-left font-medium text-gray-900 ">InStock</th>
<th class="whitespace-nowrap px-4 py-2 text-left font-medium text-gray-900 ">quantity</th>
              </tr>
            </thead>
            <tbody class="divide-y divide-gray-200" id="table-body">
            </tbody>
`
            let Ndata = "";
            console.log(Object.keys(res[0]))
            res.forEach((value, index) => {
                Ndata += ` 
              <tr class="" >
              <center>
                <td id="name" class=" whitespace-nowrap pl-[8rem] py-2 font-medium text-gray-900 ">${value.userId.name} </td>
                <td id="name" class=" whitespace-nowrap pl-4 py-2 text-gray-700 ">${value.userId.phone} </td>
                <td id="name" class="whitespace-nowrap pl-4 py-2 text-gray-700 ">${value.userId.email} </td>
              <td id="phone" class="whitespace-nowrap pl-4 py-2 text-gray-700 ">${value.productId.name} </td>
              <td id="phone" class="whitespace-nowrap pl-4 py-2 text-gray-700 ">${value.productId.price} </td>
              <td id="email" class="whitespace-nowrap pl-4 py-2 text-gray-700 ">${value.productId.salePrice} </td>
              <td id="email" class="whitespace-nowrap pl-4 py-2 text-gray-700 ">${value.productId.stock} </td>
              <td id="email" class="whitespace-nowrap pl-4 py-2 font-medium text-gray-900 ">${value.quantity} </td>
             
              </center>
              </tr>
            
        `
            });

            document.getElementById("table-body").innerHTML = Ndata;
        },
        error: function (req, err) {
            alert("Failed");
            console.log(err);
        },

    });
}