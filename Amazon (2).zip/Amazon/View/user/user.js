//-----------------------Main section shows on first page-----------------------------------------------------------------------------
function mainpage() {

  let data = "";




  data = ` 
     <section class="bg-gray-900 text-white " id="section">
     <div class="mx-auto max-w-screen-xl px-4 py-32 lg:flex lg:h-screen lg:items-center">
       <div class="mx-auto max-w-3xl text-center">
         <h1
           class="bg-gradient-to-r from-green-300 via-blue-500 to-purple-600 bg-clip-text text-3xl font-extrabold text-transparent sm:text-5xl">
           Welcome to Bhatia's Textile

           <span class="sm:block"></span>
         </h1>

         <p class="mx-auto mt-4 max-w-xl sm:text-xl sm:leading-relaxed">
           Thank's For Choosing Our Site
         </p>

         <div class="mt-8 flex flex-wrap justify-center gap-4">
           <a onclick="products2(); return false"
             class="block w-full rounded border border-blue-600 bg-blue-600 px-12 py-3 text-sm font-medium text-white hover:bg-transparent hover:text-white focus:outline-none focus:ring active:text-opacity-75 sm:w-auto"
             href="">
             Get Started
           </a>

           <a onclick="Vcategories(); return false"
             class="block w-full rounded border border-blue-600 px-12 py-3 text-sm font-medium text-white hover:bg-blue-600 focus:outline-none focus:ring active:bg-blue-500 sm:w-auto"
             href="">
             View By Categories
           </a>
         </div>
       </div>
     </div>
   </section>

   `
  document.getElementById("body").innerHTML = data;



  let Mdata = "";

  Mdata = ` 
  <footer aria-label="Site Footer" class="bg-white">
  <div class="max-w-screen-xl px-4 pt-16 pb-8 mx-auto sm:px-6 lg:px-8 lg:pt-24">
    <div class="text-center">
      <h2 class="text-3xl font-extrabold text-gray-900 sm:text-5xl">
        Customise Your Product
      </h2>

      <p class="max-w-sm mx-auto mt-4 text-gray-500">
      "Shop from the comfort of your own home - with just a few clicks!"
      </p>

      <a
        href="#"
        class="inline-block px-12 py-3 mt-8 text-sm font-medium text-indigo-600 border border-indigo-600 rounded-full hover:bg-indigo-600 hover:text-white focus:outline-none focus:ring active:bg-indigo-500"
      >
        Get Started
      </a>
    </div>

    <div
      class="pt-8 mt-16 border-t border-gray-100 sm:flex sm:items-center sm:justify-between lg:mt-24"
    >
      <nav aria-label="Footer Navigation - Support">
        <ul class="flex flex-wrap justify-center gap-4 text-xs lg:justify-end">
          <li>
            <a href="#" class="text-gray-500 transition hover:opacity-75">
              Terms & Conditions
            </a>
          </li>

          <li>
            <a href="#" class="text-gray-500 transition hover:opacity-75">
              Privacy Policy
            </a>
          </li>

          <li>
            <a href="#" class="text-gray-500 transition hover:opacity-75">
              Cookies
            </a>
          </li>
        </ul>
      </nav>

      <ul class="flex justify-center gap-6 mt-8 sm:mt-0 lg:justify-end">
        <li>
          <a
            href="/"
            rel="noreferrer"
            target="_blank"
            class="text-gray-700 transition hover:opacity-75"
          >
            <span class="sr-only">Facebook</span>

            <svg
              class="w-6 h-6"
              fill="currentColor"
              viewBox="0 0 24 24"
              aria-hidden="true"
            >
              <path
                fill-rule="evenodd"
                d="M22 12c0-5.523-4.477-10-10-10S2 6.477 2 12c0 4.991 3.657 9.128 8.438 9.878v-6.987h-2.54V12h2.54V9.797c0-2.506 1.492-3.89 3.777-3.89 1.094 0 2.238.195 2.238.195v2.46h-1.26c-1.243 0-1.63.771-1.63 1.562V12h2.773l-.443 2.89h-2.33v6.988C18.343 21.128 22 16.991 22 12z"
                clip-rule="evenodd"
              />
            </svg>
          </a>
        </li>

        <li>
          <a
            href="/"
            rel="noreferrer"
            target="_blank"
            class="text-gray-700 transition hover:opacity-75"
          >
            <span class="sr-only">Instagram</span>

            <svg
              class="w-6 h-6"
              fill="currentColor"
              viewBox="0 0 24 24"
              aria-hidden="true"
            >
              <path
                fill-rule="evenodd"
                d="M12.315 2c2.43 0 2.784.013 3.808.06 1.064.049 1.791.218 2.427.465a4.902 4.902 0 011.772 1.153 4.902 4.902 0 011.153 1.772c.247.636.416 1.363.465 2.427.048 1.067.06 1.407.06 4.123v.08c0 2.643-.012 2.987-.06 4.043-.049 1.064-.218 1.791-.465 2.427a4.902 4.902 0 01-1.153 1.772 4.902 4.902 0 01-1.772 1.153c-.636.247-1.363.416-2.427.465-1.067.048-1.407.06-4.123.06h-.08c-2.643 0-2.987-.012-4.043-.06-1.064-.049-1.791-.218-2.427-.465a4.902 4.902 0 01-1.772-1.153 4.902 4.902 0 01-1.153-1.772c-.247-.636-.416-1.363-.465-2.427-.047-1.024-.06-1.379-.06-3.808v-.63c0-2.43.013-2.784.06-3.808.049-1.064.218-1.791.465-2.427a4.902 4.902 0 011.153-1.772A4.902 4.902 0 015.45 2.525c.636-.247 1.363-.416 2.427-.465C8.901 2.013 9.256 2 11.685 2h.63zm-.081 1.802h-.468c-2.456 0-2.784.011-3.807.058-.975.045-1.504.207-1.857.344-.467.182-.8.398-1.15.748-.35.35-.566.683-.748 1.15-.137.353-.3.882-.344 1.857-.047 1.023-.058 1.351-.058 3.807v.468c0 2.456.011 2.784.058 3.807.045.975.207 1.504.344 1.857.182.466.399.8.748 1.15.35.35.683.566 1.15.748.353.137.882.3 1.857.344 1.054.048 1.37.058 4.041.058h.08c2.597 0 2.917-.01 3.96-.058.976-.045 1.505-.207 1.858-.344.466-.182.8-.398 1.15-.748.35-.35.566-.683.748-1.15.137-.353.3-.882.344-1.857.048-1.055.058-1.37.058-4.041v-.08c0-2.597-.01-2.917-.058-3.96-.045-.976-.207-1.505-.344-1.858a3.097 3.097 0 00-.748-1.15 3.098 3.098 0 00-1.15-.748c-.353-.137-.882-.3-1.857-.344-1.023-.047-1.351-.058-3.807-.058zM12 6.865a5.135 5.135 0 110 10.27 5.135 5.135 0 010-10.27zm0 1.802a3.333 3.333 0 100 6.666 3.333 3.333 0 000-6.666zm5.338-3.205a1.2 1.2 0 110 2.4 1.2 1.2 0 010-2.4z"
                clip-rule="evenodd"
              />
            </svg>
          </a>
        </li>

        <li>
          <a
            href="/"
            rel="noreferrer"
            target="_blank"
            class="text-gray-700 transition hover:opacity-75"
          >
            <span class="sr-only">Twitter</span>

            <svg
              class="w-6 h-6"
              fill="currentColor"
              viewBox="0 0 24 24"
              aria-hidden="true"
            >
              <path
                d="M8.29 20.251c7.547 0 11.675-6.253 11.675-11.675 0-.178 0-.355-.012-.53A8.348 8.348 0 0022 5.92a8.19 8.19 0 01-2.357.646 4.118 4.118 0 001.804-2.27 8.224 8.224 0 01-2.605.996 4.107 4.107 0 00-6.993 3.743 11.65 11.65 0 01-8.457-4.287 4.106 4.106 0 001.27 5.477A4.072 4.072 0 012.8 9.713v.052a4.105 4.105 0 003.292 4.022 4.095 4.095 0 01-1.853.07 4.108 4.108 0 003.834 2.85A8.233 8.233 0 012 18.407a11.616 11.616 0 006.29 1.84"
              />
            </svg>
          </a>
        </li>

        <li>
          <a
            href="/"
            rel="noreferrer"
            target="_blank"
            class="text-gray-700 transition hover:opacity-75"
          >
            <span class="sr-only">GitHub</span>

            <svg
              class="w-6 h-6"
              fill="currentColor"
              viewBox="0 0 24 24"
              aria-hidden="true"
            >
              <path
                fill-rule="evenodd"
                d="M12 2C6.477 2 2 6.484 2 12.017c0 4.425 2.865 8.18 6.839 9.504.5.092.682-.217.682-.483 0-.237-.008-.868-.013-1.703-2.782.605-3.369-1.343-3.369-1.343-.454-1.158-1.11-1.466-1.11-1.466-.908-.62.069-.608.069-.608 1.003.07 1.531 1.032 1.531 1.032.892 1.53 2.341 1.088 2.91.832.092-.647.35-1.088.636-1.338-2.22-.253-4.555-1.113-4.555-4.951 0-1.093.39-1.988 1.029-2.688-.103-.253-.446-1.272.098-2.65 0 0 .84-.27 2.75 1.026A9.564 9.564 0 0112 6.844c.85.004 1.705.115 2.504.337 1.909-1.296 2.747-1.027 2.747-1.027.546 1.379.202 2.398.1 2.651.64.7 1.028 1.595 1.028 2.688 0 3.848-2.339 4.695-4.566 4.943.359.309.678.92.678 1.855 0 1.338-.012 2.419-.012 2.747 0 .268.18.58.688.482A10.019 10.019 0 0022 12.017C22 6.484 17.522 2 12 2z"
                clip-rule="evenodd"
              />
            </svg>
          </a>
        </li>

        <li>
          <a
            href="/"
            rel="noreferrer"
            target="_blank"
            class="text-gray-700 transition hover:opacity-75"
          >
            <span class="sr-only">Dribbble</span>

            <svg
              class="w-6 h-6"
              fill="currentColor"
              viewBox="0 0 24 24"
              aria-hidden="true"
            >
              <path
                fill-rule="evenodd"
                d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10c5.51 0 10-4.48 10-10S17.51 2 12 2zm6.605 4.61a8.502 8.502 0 011.93 5.314c-.281-.054-3.101-.629-5.943-.271-.065-.141-.12-.293-.184-.445a25.416 25.416 0 00-.564-1.236c3.145-1.28 4.577-3.124 4.761-3.362zM12 3.475c2.17 0 4.154.813 5.662 2.148-.152.216-1.443 1.941-4.48 3.08-1.399-2.57-2.95-4.675-3.189-5A8.687 8.687 0 0112 3.475zm-3.633.803a53.896 53.896 0 013.167 4.935c-3.992 1.063-7.517 1.04-7.896 1.04a8.581 8.581 0 014.729-5.975zM3.453 12.01v-.26c.37.01 4.512.065 8.775-1.215.25.477.477.965.694 1.453-.109.033-.228.065-.336.098-4.404 1.42-6.747 5.303-6.942 5.629a8.522 8.522 0 01-2.19-5.705zM12 20.547a8.482 8.482 0 01-5.239-1.8c.152-.315 1.888-3.656 6.703-5.337.022-.01.033-.01.054-.022a35.318 35.318 0 011.823 6.475 8.4 8.4 0 01-3.341.684zm4.761-1.465c-.086-.52-.542-3.015-1.659-6.084 2.679-.423 5.022.271 5.314.369a8.468 8.468 0 01-3.655 5.715z"
                clip-rule="evenodd"
              />
            </svg>
          </a>
        </li>
      </ul>
    </div>
  </div>
</footer>


   `
  document.getElementById("footer").innerHTML = Mdata;




}
function loguser() {




  document.getElementById("body").innerHTML = ` 
    <div class="container">
<center>
  <h1 class="text-4xl text-[#0f172a] pt-6 ">Login Here</h1>
 
    <div id="form">
      </div>
    <button type="button" id="login" onclick="login()" class="px-[8rem] py-3 text-white rounded-2xl mt-4   bg-gradient-to-r from-green-400 to-blue-500 hover:from-pink-500 hover:to-yellow-500 " onclick="signup()">
      Submit</button>
   
  </form>
</center>
</div>`


  let data = "";




  data = ` 
       <div class="w-full max-w-lg">
       <form class="bg-white shadow-md rounded px-8 pt-6 pb-8 mb-4">           
     <div class="name mt-4">
     <input type="text" name="name" id="id" visibility: hidden   placeholder="Enter Your Name Here"
       class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline ">
   </div>
 <div class="phone mt-4">
   <label for="phone" class="block text-gray-700 text-sm font-bold mb-2">Phone</label> <br>
   <input type="text" name="phone" id="phone"  placeholder="Enter Your Phone Number Here"
     class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline">
 </div>
 <div class="password mt-4">
   <label for="password" class="block text-gray-700 text-sm font-bold mb-2">Password</label> <br>
   <input type="password" name="password"  id="password" placeholder="Enter Your password Here"
     class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline">
 </div>
 </form>
 </div>
     `
  document.getElementById("form").innerHTML = data;




}
//-----------------------Login Page-----------------------------------------------------------------------------
function login() {

  var req = {

    phone: document.getElementById("phone").value,
    password: document.getElementById("password").value

  };

  $.ajax({
    type: "post",
    url: "http://localhost:3155/user/login",
    contentType: "application/json",
    headers: {

    },
    data: JSON.stringify(req),
    success: function (res) {
      console.log(res);
      // console.log(Object.values(res[0]));
      // console.log(data);
      if ((Object.keys(res[0])).includes("name") == true) {




        // console.log(Object.values(res))

        // console.log(Object.values(res[0]._id))



        var key = "name"
        var value = res[0].name

        setCookie(key, value, 365);
        var key2 = "id"
        var value2 = res[0]._id

        setCookie(key2, value2, 365);



        document.getElementById("body").innerHTML = `<div
class="mb-3 bg-green-400 inline-flex w-full items-center rounded-lg bg-success-100 py-5 px-6 text-base text-success-700"
role="alert">
<span class="mr-2">
  <svg
    xmlns="http://www.w3.org/2000/svg"
    viewBox="0 0 24 24"
    fill="currentColor"
    class="h-5 w-5">
    <path
      fill-rule="evenodd"
      d="M2.25 12c0-5.385 4.365-9.75 9.75-9.75s9.75 4.365 9.75 9.75-4.365 9.75-9.75 9.75S2.25 17.385 2.25 12zm13.36-1.814a.75.75 0 10-1.22-.872l-3.236 4.53L9.53 12.22a.75.75 0 00-1.06 1.06l2.25 2.25a.75.75 0 001.14-.094l3.75-5.25z"
      clip-rule="evenodd" />
  </svg>
</span>
${res[0].name},You are Successfully Login to your account
</div>
      `
        setTimeout(() => {

          document.getElementById("body").innerHTML = `
        <h1 class="text-3xl text-black ml-[20rem] mt-[18rem]">wait we are redirecting you to home page.....</h1>
        `

        }, 2000)
        setTimeout(() => {


          window.location.reload()

        }, 5000)



      }
      else {
        document.getElementById("body").innerHTML = `<div
class="mb-3 bg-red-400 inline-flex w-full items-center rounded-lg bg-success-100 py-5 px-6 text-base text-success-700"
role="alert">
<span class="mr-2">
<svg
xmlns="http://www.w3.org/2000/svg"
viewBox="0 0 24 24"
fill="currentColor"
class="h-5 w-5">
<path
  fill-rule="evenodd"
  d="M12 2.25c-5.385 0-9.75 4.365-9.75 9.75s4.365 9.75 9.75 9.75 9.75-4.365 9.75-9.75S17.385 2.25 12 2.25zm-1.72 6.97a.75.75 0 10-1.06 1.06L10.94 12l-1.72 1.72a.75.75 0 101.06 1.06L12 13.06l1.72 1.72a.75.75 0 101.06-1.06L13.06 12l1.72-1.72a.75.75 0 10-1.06-1.06L12 10.94l-1.72-1.72z"
  clip-rule="evenodd" />
</svg>
</span>
Invalid credentials ,Please Try Again
</div>
      `
        setTimeout(() => {
          loguser()
        }, 3000)
      }


      // window.location.href = "/View/user/login.html";
    },
    error: function (req, err) {
      // alert("Failed");

      console.log(err);
    },

  });

}
//-----------------------Add User-----------------------------------------------------------------------------
function Adduser() {




  document.getElementById("body").innerHTML = ` 
        <div class="container">
    <center>
      <h1 class="text-4xl text-[#0f172a] pt-6 ">Sign Up</h1>
     
        <div id="form">
          </div>
        <button type="button" onclick="signup()" class="px-[8rem] py-3 text-white rounded-2xl mt-4   bg-gradient-to-r from-green-400 to-blue-500 hover:from-pink-500 hover:to-yellow-500 " onclick="signup()">
          Submit</button>
       
      </form>
    </center>
    </div>`


  let data = "";




  data = ` 
           <div class="w-full max-w-lg">
           <form class="bg-white shadow-md rounded px-8 pt-6 pb-8 mb-4">           
         <div class="name mt-4">
         <input type="text" name="name" id="id" visibility: hidden   placeholder="Enter Your Name Here"
           class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline ">
       </div>
       <div class="name mt-4">
       <label for="name" class="block text-gray-700 text-sm font-bold mb-2">Name</label> <br>
       <input type="text" name="name" id="name"   placeholder="Enter Your Name Here"
         class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline ">
     </div>
     <div class="phone mt-4">
       <label for="phone" class="block text-gray-700 text-sm font-bold mb-2">Phone</label> <br>
       <input type="text" name="phone" id="phone"  placeholder="Enter Your Phone Number Here"
         class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline">
     </div>
     <div class="email mt-4">
       <label for="email" class="block text-gray-700 text-sm font-bold mb-2">Email</label> <br>
       <input type="email" name="email" id="email"  placeholder="Enter Your email Here"
         class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline">
     </div>
     <div class="password mt-4">
       <label for="password" class="block text-gray-700 text-sm font-bold mb-2">Password</label> <br>
       <input type="password" name="password"  id="password" placeholder="Enter Your password Here"
         class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline">
     </div>
     </form>
     </div>
         `
  document.getElementById("form").innerHTML = data;




}
//-----------------------Signup page-----------------------------------------------------------------------------
function signup() {

  var req = {

    name: document.getElementById("name").value,
    phone: document.getElementById("phone").value,
    email: document.getElementById("email").value,
    password: document.getElementById("password").value

  };

  $.ajax({
    type: "post",
    url: "http://localhost:3155/user/signup",

    headers: {

    },
    data: (req),
    success: function (res) {
      // alert("Done");
      console.log(res);
      document.getElementById("body").innerHTML = `<div
    class="mb-3 bg-green-400 inline-flex w-full items-center rounded-lg bg-success-100 py-5 px-6 text-base text-success-700"
    role="alert">
    <span class="mr-2">
      <svg
        xmlns="http://www.w3.org/2000/svg"
        viewBox="0 0 24 24"
        fill="currentColor"
        class="h-5 w-5">
        <path
          fill-rule="evenodd"
          d="M2.25 12c0-5.385 4.365-9.75 9.75-9.75s9.75 4.365 9.75 9.75-4.365 9.75-9.75 9.75S2.25 17.385 2.25 12zm13.36-1.814a.75.75 0 10-1.22-.872l-3.236 4.53L9.53 12.22a.75.75 0 00-1.06 1.06l2.25 2.25a.75.75 0 001.14-.094l3.75-5.25z"
          clip-rule="evenodd" />
      </svg>
    </span>
    ${res} redirecting you to login page..............
  </div>
          `

      setTimeout(() => {
        loguser()
      }, 3000)



      // window.location.href = "/View/user/login.html";
    },
    error: function (req, err) {
      // alert("Failed");
      document.getElementById("body").innerHTML = `<div
    class="mb-3 bg-red-400 inline-flex w-full items-center rounded-lg bg-success-100 py-5 px-6 text-base text-success-700"
    role="alert">
    <span class="mr-2">
    <svg
    xmlns="http://www.w3.org/2000/svg"
    viewBox="0 0 24 24"
    fill="currentColor"
    class="h-5 w-5">
    <path
      fill-rule="evenodd"
      d="M12 2.25c-5.385 0-9.75 4.365-9.75 9.75s4.365 9.75 9.75 9.75 9.75-4.365 9.75-9.75S17.385 2.25 12 2.25zm-1.72 6.97a.75.75 0 10-1.06 1.06L10.94 12l-1.72 1.72a.75.75 0 101.06 1.06L12 13.06l1.72 1.72a.75.75 0 101.06-1.06L13.06 12l1.72-1.72a.75.75 0 10-1.06-1.06L12 10.94l-1.72-1.72z"
      clip-rule="evenodd" />
  </svg>
    </span>
    ${res}
  </div>
          `
      const myTimeout = setTimeout(function alert() {
        document.getElementById("body").style.display = "none";
      }, 5000);
      console.log(err);
    },

  });
}

// ----------------------------here part 2 start --------------------------------------------------------------
//-----------------------View Categories-----------------------------------------------------------------------------
function Vcategories() {

  var req = {


  };


  $.ajax({
    type: "post",
    url: "http://localhost:3155/admin/Cview",

    headers: {

    },
    data: (req),
    success: function (res) {

      console.log(res);
      let Ndata = "";
      for (const value of res) {
        console.log(value)
        Ndata += ` 

  <a
  href=""
  onclick="products('${value._id}'); return false"
  class="relative block mx-[30rem] my-3 w-[40%] overflow-hidden rounded-xl bg-[url(https://images.unsplash.com/photo-1552832230-c0197dd311b5?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1592&q=80)] bg-cover bg-center bg-no-repeat"
>
  <div class="absolute inset-0 bg-black/25"></div>

  <div class="relative flex items-start justify-between p-4 sm:p-6 lg:p-8">
    <div class="sm:pt-18 pt-12 text-white lg:pt-24">
      <h3 class="text-xl font-bold sm:text-2xl">${value.category}</h3>

    </div>

  </div>
</a>


`

      }


      // res.map((value, index) => {

      // });

      document.getElementById("body").innerHTML = Ndata;
    },
    error: function (req, err) {
      alert("Failed");
      console.log(err);
    },

  });
}

//----------------------- main function toshow products-----------------------------------------------------------------------------
function products(_id) {


  var req = {

    _id: _id
  };


  $.ajax({
    type: "post",
    url: "http://localhost:3155/admin/viewimage",

    headers: {

    },
    data: JSON.stringify(req),
    success: function (res) {

      console.log(res);



      let Ndata = ""
      res.forEach((value, index) => {
        if (value.ProductId.categoryId._id == _id) {
// image(value._id)
          Ndata += `
                
 
                <a href="" onclick="productfull('${value.ProductId._id}'); vimage('${value.ProductId._id}'); return false" id="singleProduct" productid="${value._id}" class="group   w-[25%] inline-block ml-[5.5rem] overflow-hidden">
                <div class="relative h-[350px] sm:h-[450px]" id="img3155">
                <img
                src="http://localhost:3155/img/${value.ImageId}"
                alt=""
                class="absolute inset-0 h-full w-full object-cover opacity-100 "
              />
                </div>
              
                <div class="relative bg-white pt-3">
                  <h3
                    class="text-xl text-gray-700 group-hover:underline group-hover:underline-offset-4"
                  >
                    ${value.ProductId.name}
                  </h3>
              
                  <p class="mt-1.5 tracking-wide text-gray-900">₹${value.ProductId.salePrice}</p>
                  <p class="mt-1.5 text-lg tracking-wide text-gray-900">Category:-</p>
                  <p class="mt-1.5 tracking-wide text-gray-900">${value.ProductId.categoryId.category}</p>
                </div>
              </a>
              
  
                
        `
        }
      });



      document.getElementById("body").innerHTML = Ndata;







    },
    error: function (req, err) {
      alert("Failed");
      console.log(err);
    },

  });
}

//----------------------- second function for products----------------------------------------------------------------------------
function products2() {


  var req = {


  };


  $.ajax({
    type: "post",
    url: "http://localhost:3155/admin/viewimage",
    headers: {

    },
    data: JSON.stringify(req),
    success: function (res) {

      console.log(res);



      let Ndata = ""
      res.forEach((value, index) => {


        Ndata += `
                
 
                <a href="" onclick="productfull('${value.ProductId._id}'); vimage('${value.ProductId._id}'); return false" class="group   w-[25%] inline-block ml-[5.5rem] overflow-hidden">
                <div class="relative h-[350px] sm:h-[450px]">
                  <img
                    src="http://localhost:3155/img/${value.ImageId}"
                    alt=""
                    class="absolute inset-0 h-full w-full object-cover opacity-100 group-hover:opacity-50"
                  />
                </div>
              
                <div class="relative bg-white pt-3">
                  <h3
                    class="text-xl text-gray-700 group-hover:underline group-hover:underline-offset-4"
                  >
                    ${value.ProductId.name}
                  </h3>
              
                  <p class="mt-1.5 tracking-wide text-gray-900">₹${value.ProductId.salePrice}</p>
                  <p class="mt-1.5 text-lg tracking-wide text-gray-900">Category:-</p>
                  <p class="mt-1.5 tracking-wide text-gray-900">${value.ProductId.categoryId.category}</p>
                </div>
              </a>
              
  
                
        `

      });



      document.getElementById("body").innerHTML = Ndata;







    },
    error: function (req, err) {
      alert("Failed");
      console.log(err);
    },

  });
}

//-----------------------Product full view-----------------------------------------------------------------------------
function productfull(_id) {

  var req = {
    _id: _id

  };
console.log(_id)


  $.ajax({
    type: "post",
    url: "http://localhost:3155/user/products",
    // contentType: "application/json",
    headers: {

    },
    data: (req),
    success: function (res) {
      let id = res[0]._id
      let name = res[0].name
      let featuredImage = res[0].featuredImage
      let price = res[0].price
      let salePrice = res[0].salePrice
      let description = res[0].description
      let stock = res[0].stock
      let category = res[0].categoryId.category
      console.log(res);




      let Ndata = ""

      Ndata = `
              
            <section>
              <div class="relative mx-auto max-w-screen-xl px-4 py-8">
                <div class="grid grid-cols-1 items-start gap-8 md:grid-cols-2">
                  <div class="grid grid-cols-2 gap-4 md:grid-cols-1" id="image3000">
                    
            
                    
                  </div>
            
                  <div class="sticky top-0">
                  <strong
                  class="rounded-full border border-blue-600 bg-gray-100 px-3 py-0.5 text-xs font-medium tracking-wide text-blue-600"
                >
                  ${category}
                </strong>
                    <div class="mt-8 flex justify-between">
                      <div class="max-w-[35ch] space-y-2">
                        <h1 class="text-xl font-bold sm:text-2xl">
                          ${name}
                        </h1>
            
                        <p class="text-sm">Highest Rated Product</p>
            
                       
                      </div>
            
                      <p class="text-lg font-bold">₹${salePrice}</p>
                    </div>
                    
            
                    <p class="text-lg font-bold" id="foralert"></p>
               
          
                    <div class="mt-4">
                      <div class="prose max-w-none">
                        <p>
                         ${description}
                        </p>
                      </div>
            
                      <p>
                        Only ${stock} left, Hurry Up!
                        </p>
                    </div>
            
                    <form class="mt-8">
                      <fieldset>
                        <legend class="mb-1 text-sm font-medium">Color</legend>
            
                        <div class="flex flex-wrap gap-1">
                          <label for="color_tt" class="cursor-pointer">
                            <input
                              type="radio"
                              name="color"
                              id="color_tt"
                              class="peer sr-only"
                            />
            
                            <span
                              class="group inline-block rounded-full border px-3 py-1 text-xs font-medium peer-checked:bg-black peer-checked:text-white"
                            >
                              Texas Tea
                            </span>
                          </label>
            
                          <label for="color_fr" class="cursor-pointer">
                            <input
                              type="radio"
                              name="color"
                              id="color_fr"
                              class="peer sr-only"
                            />
            
                            <span
                              class="group inline-block rounded-full border px-3 py-1 text-xs font-medium peer-checked:bg-black peer-checked:text-white"
                            >
                              Fiesta Red
                            </span>
                          </label>
            
                          <label for="color_cb" class="cursor-pointer">
                            <input
                              type="radio"
                              name="color"
                              id="color_cb"
                              class="peer sr-only"
                            />
            
                            <span
                              class="group inline-block rounded-full border px-3 py-1 text-xs font-medium peer-checked:bg-black peer-checked:text-white"
                            >
                              Cobalt Blue
                            </span>
                          </label>
                        </div>
                      </fieldset>
            
                      <fieldset class="mt-4">
                        <legend class="mb-1 text-sm font-medium">Size</legend>
            
                        <div class="flex flex-wrap gap-1">
                          <label for="size_xs" class="cursor-pointer">
                            <input
                              type="radio"
                              name="size"
                              id="size_xs"
                              class="peer sr-only"
                            />
            
                            <span
                              class="group inline-flex h-8 w-8 items-center justify-center rounded-full border text-xs font-medium peer-checked:bg-black peer-checked:text-white"
                            >
                              XS
                            </span>
                          </label>
            
                          <label for="size_s" class="cursor-pointer">
                            <input
                              type="radio"
                              name="size"
                              id="size_s"
                              class="peer sr-only"
                            />
            
                            <span
                              class="group inline-flex h-8 w-8 items-center justify-center rounded-full border text-xs font-medium peer-checked:bg-black peer-checked:text-white"
                            >
                              S
                            </span>
                          </label>
            
                          <label for="size_m" class="cursor-pointer">
                            <input
                              type="radio"
                              name="size"
                              id="size_m"
                              class="peer sr-only"
                            />
            
                            <span
                              class="group inline-flex h-8 w-8 items-center justify-center rounded-full border text-xs font-medium peer-checked:bg-black peer-checked:text-white"
                            >
                              M
                            </span>
                          </label>
            
                          <label for="size_l" class="cursor-pointer">
                            <input
                              type="radio"
                              name="size"
                              id="size_l"
                              class="peer sr-only"
                            />
            
                            <span
                              class="group inline-flex h-8 w-8 items-center justify-center rounded-full border text-xs font-medium peer-checked:bg-black peer-checked:text-white"
                            >
                              L
                            </span>
                          </label>
            
                          <label for="size_xl" class="cursor-pointer">
                            <input
                              type="radio"
                              name="size"
                              id="size_xl"
                              class="peer sr-only"
                            />
            
                            <span
                              class="group inline-flex h-8 w-8 items-center justify-center rounded-full border text-xs font-medium peer-checked:bg-black peer-checked:text-white"
                            >
                              XL
                            </span>
                          </label>
                        </div>
                      </fieldset>
            
                      <div class="mt-8 flex gap-4">
                        <div>
                          <label for="quantity" class="sr-only">Qty</label>
            
                          <input
                            type="number"
                            id="quantity"
                            min="1"
                            value="1"
                            class="w-12 rounded border-gray-200 py-3 text-center text-xs [-moz-appearance:_textfield] [&::-webkit-outer-spin-button]:m-0 [&::-webkit-outer-spin-button]:appearance-none [&::-webkit-inner-spin-button]:m-0 [&::-webkit-inner-spin-button]:appearance-none"
                          />
                        </div>
            
                        <button
                          type="button"
                          onclick="addtocart('${id}')"
                          class="block rounded bg-green-600 px-5 py-3 text-xs font-medium text-white hover:bg-green-500"
                        >
                          Add to Cart
                        </button>
                        <button
                          type="button"
                          onclick="Vbuynow('${id}')"
                          class="block rounded bg-green-600 px-5 py-3 text-xs font-medium text-white hover:bg-green-500"
                        >
                          Buy Now
                        </button>
                      </div>
                    </form>
                  </div>
                </div>
              </div>
            </section>
            

              
      `







      document.getElementById("body").innerHTML = Ndata;
    },
    error: function (req, err) {
      alert("Failed");
      console.log(err);
    },

  });
}
function vimage(_id) {

  var req = {
    _id: _id

  };
console.log(_id)

  $.ajax({
    type: "post",
    url: "http://localhost:3155/admin/viewimage",
    // contentType: "application/json",

    headers: {

    },
    data: JSON.stringify(req),
    success: function (res) {

console.log(res)

      let Ndata = ""
      

for(let i = 0 ; i<res.length;i++)
{
console.log(res[i])
if(res[i].ProductId._id == _id)
{


  Ndata = `
   
  <img
  alt="Les Paul"
  src="http://localhost:3155/img/${res[i].ImageId}"
  class="aspect-square w-full rounded-xl object-cover"
  />
  
   
  `
}
}
     
     



      document.getElementById("image3000").innerHTML = Ndata;
    },
    error: function (req, err) {
      alert("Failed");
      console.log(err);
    },

  });
}

//-----------------------Add to cart-----------------------------------------------------------------------------

function addtocart(id) {

  let user2 = getCookie("id");
  console.log(id)
  var req = {
    UserId: user2,
    productId: id,
    quantity: document.getElementById("quantity").value
  };

  let gaama = checkCookie();
  if (gaama == true && gaama != undefined) {


    $.ajax({
      type: "post",
      url: "http://localhost:3155/user/addtocart",
      contentType: "application/json",
      headers: {

      },
      data: JSON.stringify(req),

      success: function (res) {
        setTimeout(() => {


          document.getElementById("foralert").innerHTML = `<div
    class="mb-3 bg-emerald-400 inline-flex w-full items-center rounded-lg bg-success-100 py-5 px-6 text-base text-success-700"
    role="alert">
    <span class="mr-2">
    <svg
    xmlns="http://www.w3.org/2000/svg"
    viewBox="0 0 24 24"
    fill="currentColor"
    class="h-5 w-5">
    <path
      fill-rule="evenodd"
      d="M12 2.25c-5.385 0-9.75 4.365-9.75 9.75s4.365 9.75 9.75 9.75 9.75-4.365 9.75-9.75S17.385 2.25 12 2.25zm-1.72 6.97a.75.75 0 10-1.06 1.06L10.94 12l-1.72 1.72a.75.75 0 101.06 1.06L12 13.06l1.72 1.72a.75.75 0 101.06-1.06L13.06 12l1.72-1.72a.75.75 0 10-1.06-1.06L12 10.94l-1.72-1.72z"
      clip-rule="evenodd" />
  </svg>
    </span>
    ${res}
  </div>
          `

        }, 277)


        setTimeout(() => {
          viewCart()
          cvimage()
        }, 3000);

        console.log(res);

        console.log(req)


      },
      error: function (req, err) {
        alert("Failed");
        console.log(req)
        console.log(err);
      },

    });
  }
  else {
    setTimeout(() => {
      document.getElementById("body").innerHTML = `
<h1 class="text-black text-4xl  ml-[20rem] mt-[18rem]"> you need to login first</h1>
`
    }, 1000)
    setTimeout(() => {
      document.getElementById("body").innerHTML = `
    <h1 class="text-black text-4xl  ml-[20rem] mt-[18rem]">We are redirecting you to login page</h1>
    `
    }, 1000)
    setTimeout(() => {
      loguser()
    }, 5000)
  }
}

////----------------------------view cart---------------------------////////////////////////////////////
function viewCart() {

  var req = {


  };


  $.ajax({
    type: "post",
    url: "http://localhost:3155/user/viewcart",
    // contentType: "application/json",

    headers: {

    },
    data: (req),
    success: function (res) {

      let gaama = checkCookie();
      console.log(gaama)
      if (gaama == true && gaama != undefined) {
        console.log(res);


        document.getElementById("body").innerHTML = `
          

        <div class="flex ml-[26rem] flex-col max-w-3xl p-6 space-y-4 sm:p-10 dark:bg-gray-900 dark:text-gray-100">
        <h2 class="text-xl font-semibold">Your cart</h2>
        <ul class="flex flex-col divide-y divide-gray-700" id="carteditem">
          
          
         
        </ul>
        <div class="space-y-1 text-right" >
          <p>Total amount:
            <span class="font-semibold" id="amount">3155 €</span>
          </p>
          <p class="text-sm dark:text-gray-400">Not including taxes and shipping costs</p>
        </div>
        <div class="flex justify-end space-x-4">
          <button onclick="products2()" type="button" class="px-6 py-2 border rounded-md dark:border-violet-400">Back
            <span class="sr-only sm:not-sr-only">to shop</span>
          </button>
          <button type="button" id="checkouting" class="px-6 py-2 border rounded-md dark:bg-violet-400 dark:text-gray-900 dark:border-violet-400">
            <span class="sr-only sm:not-sr-only">Continue to</span>Checkout
          </button>
        </div>
      </div>
      
        
       
          
  `

        let Mdata = ""
        let user2 = getCookie("id");
      
        res.map((value, index) => {
          if (value.UserId._id == user2) {
           
            Mdata += ` 
            <li class="flex flex-col py-6 sm:flex-row sm:justify-between">
            <div class="flex w-full space-x-2 sm:space-x-4">
            
              <div class="flex flex-col justify-between w-full pb-4">
                <div class="flex justify-between w-full pb-2 space-x-2">
                  <div class="space-y-1">
                    <h3 class="text-lg font-semibold leading-snug sm:pr-8">${value.productId.name}</h3>
                    <p class="text-sm dark:text-gray-400">${value.productId.description}</p>
                  </div>
                  <div class="text-right">
                  <input
                  type="number" readonly
                  min="1"
                  value=${value.quantity}
                  id="Line3Qty"
                  class="h-8 w-12 rounded border-gray-200 bg-gray-50 p-0 text-center text-xs text-gray-600 [-moz-appearance:_textfield] focus:outline-none [&::-webkit-outer-spin-button]:m-0 [&::-webkit-outer-spin-button]:appearance-none [&::-webkit-inner-spin-button]:m-0 [&::-webkit-inner-spin-button]:appearance-none"
                />
                    <p class="text-lg font-semibold">₹${value.productId.salePrice}</p>
                  </div>
                </div>
                <div class="flex text-sm divide-x">
                  <button onclick="deletefromcart('${value.productId._id}')" type="button" class="flex items-center px-2 py-1 pl-0 space-x-1">
                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512" class="w-4 h-4 fill-current hover:fill-red-500">
                      <path d="M96,472a23.82,23.82,0,0,0,23.579,24H392.421A23.82,23.82,0,0,0,416,472V152H96Zm32-288H384V464H128Z"></path>
                      <rect width="32" height="200" x="168" y="216"></rect>
                      <rect width="32" height="200" x="240" y="216"></rect>
                      <rect width="32" height="200" x="312" y="216"></rect>
                      <path d="M328,88V40c0-13.458-9.488-24-21.6-24H205.6C193.488,16,184,26.542,184,40V88H64v32H448V88ZM216,48h80V88H216Z"></path>
                    </svg>
                    <span>Remove</span>
                  </button>
                  
                </div>
              </div>
            </div>
          </li>
    `

          }
         
          let total = 0

          res.forEach((value) => {
            
            if (value.UserId._id == user2) {
              total = total + Number(value.quantity * value.productId.salePrice)
            }
           
          });
          if (total == 0)
            {
              document.getElementById("checkouting").style.display ="none"
              setTimeout(() => {
                mainpage()
              }, 3000);
            }
            console.log(total)
          document.getElementById("amount").innerHTML = total
        })




        document.getElementById("carteditem").innerHTML = Mdata;

      }

      else {
        document.getElementById("body").innerHTML = `
               

        <div class="flex ml-[26rem] flex-col max-w-3xl p-6 space-y-4 sm:p-10 dark:bg-gray-900 dark:text-gray-100">
        <h2 class="text-xl font-semibold">Your cart</h2>
        <ul class="flex flex-col divide-y divide-gray-700" id="carteditem">
          
        <h1
        class=" text-5xl text-black">
        UH! Oh 🤨 you need to login first!

        <span class="sm:block"></span>
      </h1>
         
        </ul>
        <div class="space-y-1 text-right" >
          <p>Total amount:
            <span class="font-semibold" id="amount">3155 €</span>
          </p>
          <p class="text-sm dark:text-gray-400">Not including taxes and shipping costs</p>
        </div>
        <div class="flex justify-end space-x-4">
          <button type="button" class="px-6 py-2 border rounded-md dark:border-violet-400">Back
            <span class="sr-only sm:not-sr-only">to shop</span>
          </button>
          
        </div>
      </div>
      
            
`

      }
    },
    error: function (req, err) {
      alert("Failed");
      console.log(err);
    },

  });
}

//-----------------------delete from cart-------------------------------------------------------------------------
function deletefromcart(_id) {

  let user2 = getCookie("id");
  console.log(_id)
  var req = {
    UserId: user2,
    productId: _id,
  };

  let gaama = checkCookie();
  if (gaama == true && gaama != undefined) {


    $.ajax({
      type: "post",
      url: "http://localhost:3155/user/removefromcart",
      headers: {

      },
      data: (req),

      success: function (res) {
        setTimeout(() => {


          document.getElementById("foralert2").innerHTML = `<div
    class="mb-3 bg-red-400 inline-flex w-full items-center rounded-lg bg-success-100 py-5 px-6 text-base text-success-700"
    role="alert">
    <span class="mr-2">
    <svg
    xmlns="http://www.w3.org/2000/svg"
    viewBox="0 0 24 24"
    fill="currentColor"
    class="h-5 w-5">
    <path
      fill-rule="evenodd"
      d="M12 2.25c-5.385 0-9.75 4.365-9.75 9.75s4.365 9.75 9.75 9.75 9.75-4.365 9.75-9.75S17.385 2.25 12 2.25zm-1.72 6.97a.75.75 0 10-1.06 1.06L10.94 12l-1.72 1.72a.75.75 0 101.06 1.06L12 13.06l1.72 1.72a.75.75 0 101.06-1.06L13.06 12l1.72-1.72a.75.75 0 10-1.06-1.06L12 10.94l-1.72-1.72z"
      clip-rule="evenodd" />
  </svg>
    </span>
    ${res}
  </div>
          `

        }, 277)

        setTimeout(() => {
          viewCart()
        }, 3000);


        console.log(res);

        console.log(req)


      },
      error: function (req, err) {
        alert("Failed");
        console.log(req)
        console.log(err);
      },

    });
  }
}
//-----------------------View Of buy now-------------------------------------------------------------------------
function Vbuynow(id) {

  var req = {
    _id: id

  };


  $.ajax({
    type: "post",
    url: "http://localhost:3155/user/products",
    // contentType: "application/json",

    headers: {

    },
    data: (req),
    success: function (res) {

      let id = res[0]._id
      let name = res[0].name
      let salePrice = res[0].salePrice
      let description = res[0].description
      let category = res[0].categoryId.category
      console.log(res);

      console.log(typeof (Vbuynow))
      
      let Ndata = ""
      let gaama = checkCookie();
      if (gaama == true && gaama != undefined) {

        bimage(id);

        Ndata = `
          
<div class="flex flex-col items-center  border-b bg-white py-4 sm:flex-row sm:px-10 lg:px-20 xl:px-32">
  <a href="#" class="text-2xl font-bold text-gray-800">sneekpeeks</a>
  <div class="mt-4 py-2 text-xs sm:mt-0 sm:ml-auto sm:text-base">
    <div class="relative">
      <ul class="relative flex w-full items-center justify-between space-x-2 sm:space-x-4">
        <li class="flex items-center space-x-3 text-left sm:space-x-4">
          <a class="flex h-6 w-6 items-center justify-center rounded-full bg-emerald-200 text-xs font-semibold text-emerald-700" href="#"
            ><svg xmlns="http://www.w3.org/2000/svg" class="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
              <path stroke-linecap="round" stroke-linejoin="round" d="M5 13l4 4L19 7" /></svg
          ></a>
          <span class="font-semibold text-gray-900">Shop</span>
        </li>
        <svg xmlns="http://www.w3.org/2000/svg" class="h-4 w-4 text-gray-400" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
          <path stroke-linecap="round" stroke-linejoin="round" d="M9 5l7 7-7 7" />
        </svg>
        <li class="flex items-center space-x-3 text-left sm:space-x-4">
          <a class="flex h-6 w-6 items-center justify-center rounded-full bg-gray-600 text-xs font-semibold text-white ring ring-gray-600 ring-offset-2" href="#">2</a>
          <span class="font-semibold text-gray-900">Shipping</span>
        </li>
        <svg xmlns="http://www.w3.org/2000/svg" class="h-4 w-4 text-gray-400" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
          <path stroke-linecap="round" stroke-linejoin="round" d="M9 5l7 7-7 7" />
        </svg>
        <li class="flex items-center space-x-3 text-left sm:space-x-4">
          <a class="flex h-6 w-6 items-center justify-center rounded-full bg-gray-400 text-xs font-semibold text-white" href="#">3</a>
          <span class="font-semibold text-gray-500">Payment</span>
        </li>
      </ul>
    </div>
  </div>
</div>
<div class="grid ml-[30rem] sm:px-10 lg:grid-cols-2 lg:px-20 xl:px-32">
  <div class="px-4 pt-8">
    <p class="text-xl font-medium">Order Summary</p>
    <p class="text-gray-400">Check your items. And select a suitable shipping method.</p>
    <div class="mt-8 space-y-3 rounded-lg border bg-white px-2 py-4 sm:px-6">
      <div class="flex flex-col rounded-lg bg-white sm:flex-row" >
<div id="buynowimage">
</div>
        <div class="flex w-full flex-col px-4 py-4">
          <span class="font-semibold">${name}</span>
          <span class="float-right text-gray-400">${description}</span>
          <span class="float-right text-gray-400">${category}</span>
          <p class="text-lg font-bold">₹${salePrice}</p>
          <input
          type="number" 
          min="1"
          value="1"
          id="quantityofprod"
          class="h-8 w-12 rounded border-gray-200 bg-gray-50 p-0 text-center text-xs text-gray-600 [-moz-appearance:_textfield] focus:outline-none [&::-webkit-outer-spin-button]:m-0 [&::-webkit-outer-spin-button]:appearance-none [&::-webkit-inner-spin-button]:m-0 [&::-webkit-inner-spin-button]:appearance-none"
        />
        </div>
      </div>
  </div>
  <div class="mt-10 bg-gray-50 px-4 pt-8 lg:mt-0">
    <p class="text-xl font-medium">Payment Details</p>
    <p class="text-gray-400">Complete your order by providing your payment details.</p>
    <div class="">
      <label for="email" class="mt-4 mb-2 block text-sm font-medium">Email</label>
      <div class="relative">
        <input type="text" id="email" name="email" class="w-full rounded-md border border-gray-200 px-4 py-3 pl-11 text-sm shadow-sm outline-none focus:z-10 focus:border-blue-500 focus:ring-blue-500" placeholder="your.email@gmail.com" />
        <div class="pointer-events-none absolute inset-y-0 left-0 inline-flex items-center px-3">
          <svg xmlns="http://www.w3.org/2000/svg" class="h-4 w-4 text-gray-400" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
            <path stroke-linecap="round" stroke-linejoin="round" d="M16 12a4 4 0 10-8 0 4 4 0 008 0zm0 0v1.5a2.5 2.5 0 005 0V12a9 9 0 10-9 9m4.5-1.206a8.959 8.959 0 01-4.5 1.207" />
          </svg>
        </div>
      </div>
      <label for="card-holder" class="mt-4 mb-2 block text-sm font-medium">Card Holder</label>
      <div class="relative">
        <input type="text" id="card-holder" name="card-holder" class="w-full rounded-md border border-gray-200 px-4 py-3 pl-11 text-sm uppercase shadow-sm outline-none focus:z-10 focus:border-blue-500 focus:ring-blue-500" placeholder="Your full name here" />
        <div class="pointer-events-none absolute inset-y-0 left-0 inline-flex items-center px-3">
          <svg xmlns="http://www.w3.org/2000/svg" class="h-4 w-4 text-gray-400" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
            <path stroke-linecap="round" stroke-linejoin="round" d="M15 9h3.75M15 12h3.75M15 15h3.75M4.5 19.5h15a2.25 2.25 0 002.25-2.25V6.75A2.25 2.25 0 0019.5 4.5h-15a2.25 2.25 0 00-2.25 2.25v10.5A2.25 2.25 0 004.5 19.5zm6-10.125a1.875 1.875 0 11-3.75 0 1.875 1.875 0 013.75 0zm1.294 6.336a6.721 6.721 0 01-3.17.789 6.721 6.721 0 01-3.168-.789 3.376 3.376 0 016.338 0z" />
          </svg>
        </div>
      </div>
      <label for="card-no" class="mt-4 mb-2 block text-sm font-medium">Card Details</label>
      <div class="flex">
        <div class="relative w-7/12 flex-shrink-0">
          <input type="text" id="card-no" name="card-no" class="w-full rounded-md border border-gray-200 px-2 py-3 pl-11 text-sm shadow-sm outline-none focus:z-10 focus:border-blue-500 focus:ring-blue-500" placeholder="xxxx-xxxx-xxxx-xxxx" />
          <div class="pointer-events-none absolute inset-y-0 left-0 inline-flex items-center px-3">
            <svg class="h-4 w-4 text-gray-400" xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" viewBox="0 0 16 16">
              <path d="M11 5.5a.5.5 0 0 1 .5-.5h2a.5.5 0 0 1 .5.5v1a.5.5 0 0 1-.5.5h-2a.5.5 0 0 1-.5-.5v-1z" />
              <path d="M2 2a2 2 0 0 0-2 2v8a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V4a2 2 0 0 0-2-2H2zm13 2v5H1V4a1 1 0 0 1 1-1h12a1 1 0 0 1 1 1zm-1 9H2a1 1 0 0 1-1-1v-1h14v1a1 1 0 0 1-1 1z" />
            </svg>
          </div>
        </div>
        <input type="text" name="credit-expiry" class="w-full rounded-md border border-gray-200 px-2 py-3 text-sm shadow-sm outline-none focus:z-10 focus:border-blue-500 focus:ring-blue-500" placeholder="MM/YY" />
        <input type="text" name="credit-cvc" class="w-1/6 flex-shrink-0 rounded-md border border-gray-200 px-2 py-3 text-sm shadow-sm outline-none focus:z-10 focus:border-blue-500 focus:ring-blue-500" placeholder="CVC" />
      </div>
      <label for="billing-address" class="mt-4 mb-2 block text-sm font-medium">Billing Address</label>
      <div class="flex flex-col sm:flex-row">
        <div class="relative flex-shrink-0 sm:w-7/12">
          <input type="text" id="billing-address" name="billing-address" class="w-full rounded-md border border-gray-200 px-4 py-3 pl-11 text-sm shadow-sm outline-none focus:z-10 focus:border-blue-500 focus:ring-blue-500" placeholder="Street Address" />
          <div class="pointer-events-none absolute inset-y-0 left-0 inline-flex items-center px-3">
            <img class="h-4 w-4 object-contain" src="https://flagpack.xyz/_nuxt/4c829b6c0131de7162790d2f897a90fd.svg" alt="" />
          </div>
        </div>
        <select type="text" name="billing-state" class="w-full rounded-md border border-gray-200 px-4 py-3 text-sm shadow-sm outline-none focus:z-10 focus:border-blue-500 focus:ring-blue-500">
          <option value="State">State</option>
        </select>
        <input type="text" name="billing-zip" class="flex-shrink-0 rounded-md border border-gray-200 px-4 py-3 text-sm shadow-sm outline-none sm:w-1/6 focus:z-10 focus:border-blue-500 focus:ring-blue-500" placeholder="ZIP" />
      </div>

      <!-- Total -->
      <div class="mt-6 flex items-center justify-between">
        <p class="text-sm font-medium text-gray-900">Total</p>
        <p class="text-2xl font-semibold text-gray-900">₹${salePrice}</p>
      </div>
    </div>
    <button onclick="placeorder('${id}')" class="mt-4 mb-8 w-full rounded-md bg-gray-900 px-6 py-3 font-medium text-white">Place Order</button>
  </div>
</div>

        

          
  `
      }
      else {
        setTimeout(() => {
          loguser()
        }, 1000)

      }




      document.getElementById("body").innerHTML = Ndata;
    },
    error: function (req, err) {
      alert("Failed");
      console.log(err);
    },

  });
}
//-------------------------------------------------image for buy now-------------------------------------
function bimage(id) {

  var req = {
    _id: id

  };
console.log(id)

  $.ajax({
    type: "post",
    url: "http://localhost:3155/admin/viewimage",
    // contentType: "application/json",

    headers: {

    },
    data: JSON.stringify(req),
    success: function (res) {

console.log(res)

      let Ndata = ""
      

for(let i = 0 ; i<res.length;i++)
{
console.log(res[i])
if(res[i].ProductId._id == id)
{


  Ndata = `
   
  <img
  alt="Les Paul"
  src="http://localhost:3155/img/${res[i].ImageId}"
  class="aspect-square w-full rounded-xl object-cover"
  />
  
   
  `
}
}
     
     



      document.getElementById("buynowimage").innerHTML = Ndata;
    },
    error: function (req, err) {
      alert("Failed");
      console.log(err);
    },

  });
}
//----------------------------------order by buy now--------------------------------------------------------
function placeorder(id) {

  let user2 = getCookie("id");
  console.log(id)
  var req = {
    UserId: user2,
    productId: id,
    quantity: document.getElementById("quantityofprod").value
  };

  

    $.ajax({
      type: "post",
      url: "http://localhost:3155/user/buy",
      contentType: "application/json",
      headers: {

      },
      data: JSON.stringify(req),

      success: function (res) {
        setTimeout(() => {


          document.getElementById("body").innerHTML = `<div
    class="mb-3 bg-emerald-400 inline-flex w-full items-center rounded-lg bg-success-100 py-5 px-6 text-base text-success-700"
    role="alert">
    <span class="mr-2">
    <svg
    xmlns="http://www.w3.org/2000/svg"
    viewBox="0 0 24 24"
    fill="currentColor"
    class="h-5 w-5">
    <path
      fill-rule="evenodd"
      d="M12 2.25c-5.385 0-9.75 4.365-9.75 9.75s4.365 9.75 9.75 9.75 9.75-4.365 9.75-9.75S17.385 2.25 12 2.25zm-1.72 6.97a.75.75 0 10-1.06 1.06L10.94 12l-1.72 1.72a.75.75 0 101.06 1.06L12 13.06l1.72 1.72a.75.75 0 101.06-1.06L13.06 12l1.72-1.72a.75.75 0 10-1.06-1.06L12 10.94l-1.72-1.72z"
      clip-rule="evenodd" />
  </svg>
    </span>
    ${res}
  </div>
          `

        }, 277)


        setTimeout(() => {
          mainpage()
        }, 3000);

        console.log(res);

        console.log(req)


      },
      error: function (req, err) {
        alert("Failed");
        console.log(req)
        console.log(err);
      },

    });
  
  
}
// --------------------------cookie section start from here------------------------------------------------------
//-----------------------set cookie-----------------------------------------------------------------------------
function setCookie(cname, cvalue, exdays) {
  const d = new Date();
  d.setTime(d.getTime() + (exdays * 24 * 60 * 60 * 1000));
  let expires = "expires=" + d.toUTCString();
  document.cookie = cname + "=" + cvalue + ";" + expires + ";path=/";
  var cookie1 = document.cookie;
  return cookie1;
}
//-----------------------get cookie-----------------------------------------------------------------------------
function getCookie(cname) {
  let name = cname + "=";
  let ca = document.cookie.split(';');
  console.log(ca)
  for (let i = 0; i < ca.length; i++) {
    let c = ca[i];
    while (c.charAt(0) == ' ') {
      c = c.substring(1);
    }
    if (c.indexOf(name) == 0) {
      return c.substring(name.length, c.length);
    }
    console.log(c.substring(5))
    // return c.substring(5);
  }
  // var ans = c.substring(5)
  return "";
}
//-----------------------check cookie-----------------------------------------------------------------------------
function checkCookie() {
  let user = getCookie("name");
  console.log(user)
  // console.log(ans)
  if (user != "" && user != "undefined") {
    document.getElementById("userarea").innerHTML = user;
    document.getElementById("userarea2").innerHTML = `
    <button type="button"
  onclick="deletecookie()"
    class="text-white bg-blue-700 hover:bg-blue-800 focus:ring-4 focus:ring-blue-300 font-medium rounded-lg text-sm px-5 py-2.5 mr-2 mb-2 dark:bg-blue-600 dark:hover:bg-blue-700 focus:outline-none dark:focus:ring-blue-800">
  
    Log out
  
  </button>
    `
    return true;
  } else {
    return false
  }

}
//-----------------------delete cookie-----------------------------------------------------------------------------
function deletecookie() {
  let alpha = getCookie();
  let gaama = checkCookie();
  console.log("alpha" + alpha)
  console.log("gaama" + gaama)

  if (gaama == true && gaama != undefined) {
    document.cookie = "name=; expires=Thu, 01 Jan 1970 00:00:00 UTC; path=/;";
    document.cookie = "id=; expires=Thu, 01 Jan 1970 00:00:00 UTC; path=/;";
    setTimeout(() => {
      window.location.reload()

    }, 1000)
    console.log(document.cookie)
  }
} 
