import multer from 'multer';
import fs from 'fs';
import productSchema from "../Modal/Proschema.js";
import { response } from 'express';
const create = (req, res) => {
    new productSchema(req.body)
        .save()
        .then(() => {
            res.send("New Product Added");

        })
        .catch((err) => {
            res.send(err);

        });
};

const view = (req, res) => {

    productSchema.find(req.body).populate("categoryId")
        .then(function (data) {
            res.send(data);
        });

};

const update = (req, res) => {

    productSchema.updateMany(req.body.filter, req.body.data).then(function (data) {
        res.send(data);
    });
};
const del = (req, res) => {


    productSchema.deleteOne(req.body.filter, req.body.data).then(function (data) {
        res.send("Product deleted");
    });
}
// const Addimage = (req, res) => {

//     const upload = multer({ dest: 'imagesfolder' }).single('featuredImage');

//     upload(req, res, function () {
//         // res.send("image added")
//        console.log( req.file.filename)
// console.log(req.file);
// // res.send(req.file.filename);
// console.log(req.body);
// productSchema.updateMany({_id:req.body.ProductId},{ImageId: req.file.filename}).then(function (data) {
    
//     res.send(data);
// });
// // console.log(res)
// // res.send(res);
//         // fs.rename('dir/img/user/' + req.file.filename,
//         //     'dir/img/user/' + req.body.store_id, function (err) { });
//     });


// }

export { create, view, update, del };
