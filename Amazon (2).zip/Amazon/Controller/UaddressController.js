import addressSchema from "../Modal/UadressSchema.js";
const add = (req, res) => {
    new addressSchema(req.body)
        .save()
        .then((data) => {
            
            res.send("New address added" + "\n" + data);

        })
        .catch((err) => {
            res.send(err);

        });
};

const view = (req, res) => {

    addressSchema.find(req.body).populate("userId")
    .then(function (data) {
        res.send(data);
    });

};

const update = (req, res) => {

    addressSchema.updateOne(req.body.filter , req.body.data).then(function (data) {
     

        // res.write("category updated");
        res.send("address updated" + " \n" +data);
    });
};
const remove = (req, res) => {


    addressSchema.deleteOne(req.body).then(function (data) {

        res.send("address deleted");
    });
}
export { add, view, update, remove };
