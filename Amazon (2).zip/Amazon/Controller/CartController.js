import cartSchema from "../Modal/CartSchema.js";
import orderSchema from "../Modal/OrderSchema.js";
const buy = (req, res) => {
    new orderSchema(req.body)
        .save()
        .then(() => {
            res.send("your order is placed");

        })
        .catch((err) => {
            res.send("something went wrong" + "\n" + err);

        });
};

 
const add = (req, res) => {
    new cartSchema(req.body)
        .save()
        .then(() => {
            res.send("New item  added to the cart");

        })
        .catch((err) => {
            res.send("something went wrong" + "\n" + err);

        });
};

const view = (req, res) => {

    cartSchema.find(req.body).populate(["productId","UserId"])
    .then(function (data) {
        res.send(data);
    });

};

const update = (req, res) => {

    cartSchema.updateOne(req.body.filter, req.body.data).then(function (data) {
        res.write("cart item  updated");
        res.send(data);
    });
};
const remove = (req, res) => {


    cartSchema.deleteOne(req.body).then(function (data) {
        res.send("cart item removed");
    });
}

// function dataset(data) {
//     return {
//         "phone"  : data.phone,
//         "productId":data.productId,
//       "quantity" : data.quantity};
// }
export { add, view, update, remove , buy};
