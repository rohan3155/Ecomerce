import orderSchema from "../Modal/OrderSchema.js";
const orders = (req, res) => {

    orderSchema.find(req.body).populate(["productId","userId"])
    .then(function (data) {
        res.send(data);
        console.log(data);

    });

};

export { orders };
