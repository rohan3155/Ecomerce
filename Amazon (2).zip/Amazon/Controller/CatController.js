import categorySchema from "../Modal/Catschema.js";
const create = (req, res) => {
    new categorySchema(req.body)
        .save()
        .then((data) => {
            
            res.send("New category created");

        })
        .catch((err) => {
            res.send(err);

        });
};

const view = (req, res) => {

    categorySchema.find(req.body)
    .then(function (data) {
        res.send(data);
    });

};

const update = (req, res) => {

    categorySchema.updateMany(req.body.filter , req.body.data).then(function (data) {
     
        res.send("category updated");
    });
};
const del = (req, res) => {


    categorySchema.deleteOne(req.body.filter ,req.body).then(function (data) {

        res.send("category deleted");
    });
}
export { create, view, update, del };
