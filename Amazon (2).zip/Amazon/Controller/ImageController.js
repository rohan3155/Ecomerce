import multer from 'multer';
import fs from 'fs';
import ImageSchema from "../Modal/Imageschema.js";
import { response } from 'express';

const Addimage = (req, res) => {

    const upload = multer({ dest: 'imagesfolder' }).single('featuredImage');

    upload(req, res, function () {
     
       console.log( req.file.filename)
console.log(req.file);
console.log(req.body);
new ImageSchema({ProductId:req.body.ProductId,ImageId: req.file.filename})
        .save()
        .then(() => {
            res.send("New image Added");

        })
        .catch((err) => {
            res.send(err);

        });

    });


}
const view = (req, res) => {
    let populate = {
        "path":"ProductId",
        "populate":{
            "path":"categoryId",  
        }
    
    }
    
    ImageSchema.find(req.body).populate(populate) 
        .then(function (data) {
            res.send(data);
        });

};

const update = (req, res) => {

    ImageSchema.updateMany({_id:req.body.ProductId},{ImageId: req.file.filename}).then(function (data) {
        res.send(data);
    });
};
const del = (req, res) => {


    ImageSchema.deleteOne({_id:req.body.ProductId},{ImageId: req.file.filename}).then(function (data) {
        res.send("Image deleted");
    });
}

const rename = (req, res) => {

    renaming(req, res, function () {
       console.log( req.file.filename)
console.log(req.file);
console.log(req.body);
        fs.rename('imagesfolder' + req.file.filename,
            'imagesfolder' + req.body.ProductId, function (err) { });
    });


}

export {  view, update, del, Addimage ,rename };
