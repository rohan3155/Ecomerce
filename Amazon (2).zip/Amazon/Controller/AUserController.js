import schema from "../Modal/Uschema.js";
const create = (req, res) => {
    new schema(req.body)
        .save()
        .then(() => {
            res.send("New user Added");

        })
        .catch(() => {
            res.send("something went wrong");

        });
};

const search = (req, res) => {

    schema.find(req.body)
    .then(function (data) {
        res.send(data);
    });

};
const view = (req, res) => {

    schema.find(req.body)
    .then(function (data) {
        res.send(data);
    });

};

const update = (req, res) => {

    schema.updateMany(req.body.filter, req.body.data).then(function (data) {
        res.send(data);
    });
};
const del = (req, res) => {


    schema.deleteOne(req.body.filter, req.body.data).then(function (data) {
        res.send("user deleted");
    });
}
export { create, view, update, del,search };
