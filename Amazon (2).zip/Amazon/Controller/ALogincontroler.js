import schema from "../Modal/Aschema.js";
const login = (req, res) => {  
    schema.find(req.body).then(function () {
        res.send("You are Successfully Login to your account");
        
        
      }).catch((err) => {
        
        console.log(err);
        
  
      });
   
  };
export {login};