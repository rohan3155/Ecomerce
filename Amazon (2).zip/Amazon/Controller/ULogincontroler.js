import schema from "../Modal/Uschema.js";
const login = (req, res) => {  
    schema.find(req.body).then(function (data) {
      
        res.send(data);

      }).catch((err) => {
        
        console.log(err);
        
  
      });
   
  };

  
  
export {login};