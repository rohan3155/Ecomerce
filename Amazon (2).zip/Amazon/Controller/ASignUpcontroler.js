import schema from "../Modal/Aschema.js";
const add = (req, res) => {
  new schema(req.body)
    .save()
    .then(() => {
      res.send("Your Sign Up was successful , now you can login");
    })
    .catch(() => {
      res.send("something went wrong");
    });
};
export { add };
