import schema from "../Modal/Uschema.js";
const add = (req, res) => { 
  new schema(req.body)
    .save()
    .then(() => {
      res.send("Your Sign Up was successful , now you can login");
    })
    .catch((err) => {
      res.send(err);
    });
};
export { add };
