import productSchema from "../Modal/Proschema.js";
const view = (req, res) => {

    productSchema.find(req.body).populate("categoryId")
    .then(function (data) {
        res.send(data);
        console.log(data);

    });

};
export { view };
