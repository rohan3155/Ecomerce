import schema from "../Modal/Catschema.js";
const cat = (req,res,next)=>{
  let category = req.body.category;
  let objcategory ={"category":category};
    schema.find(objcategory).then((data) => {
        if(data.length != 0){
          res.send(data);
          
          
        }
        else{
          
          next();
        }
      });
}

const catdel = (req,res,next)=>{
    let category = req.body.category;
    let objcategory ={"category":category};
      schema.find(objcategory).then((data) => {
          if(data.length != 0){
            next();
            
          }
          else{
            res.send("Category does not exist");

          }
        });
  }

export {catdel,cat};