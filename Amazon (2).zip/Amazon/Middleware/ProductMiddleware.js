import schema from "../Modal/Catschema.js";
const prodel = (req,res,next)=>{
    let categoryId = req.body.categoryId;
    let objcategoryId ={"categoryId":categoryId};
      schema.find(objcategoryId).then((data) => {
          if(data.length != 0){
            next();
            
          }
          else{
            res.send("Product does not exist");

          }
        });
  }

export {prodel};