import schema from "../Modal/Aschema.js";
const mid = (req,res,next)=>{
  let phone = req.body.phone;
  let objphone ={"phone":phone};
    schema.find(objphone).then((data) => {
        if(data.length != 0){
          res.send("data already exists");
          console.log(data);
        }
        else{
          next();
        }
      });
}
const mid2 = (req,res,next)=>{
  let mail = req.body.mail;
  let objmail ={"mail":mail};
    schema.find(objmail).then((data) => {
        if(data.length != 0){
          res.send("data already exists");
          console.log(data.length);
        }
        else{
          next();
        }
      });
}
export {mid , mid2};