import schema from "../Modal/Uschema.js";
const mid = (req,res,next)=>{console.log(req.body);
  let phone = req.body.phone;
  let objphone ={"phone":phone};
  // console.log("Phone is:"+phone);
    schema.find(objphone).then((data) => {
        if(data.length == 0){
          next(); 
        }
        else{
         
          res.send("data already exists");
          console.log("phone is the problem");
        }
      });
}
const mid2 = (req,res,next)=>{
  let email = req.body.email;
  let objemail ={"email":email};
    schema.find(objemail).then((data) => {
        if(data.length == 0){
          next();
         
        }
        else{
          res.send("data already exists");
          // console.log(data);
          console.log("email is the problem");
        }
      });
}
export {mid , mid2};