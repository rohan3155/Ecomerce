import schema from "../Modal/Aschema.js";
const mid3 = (req,res,next)=>{
  let phone = req.body.phone;
  let objphone = {"phone": phone};
  schema.find(objphone).then((data) => {
    if(data.length != 0){
      next();
        
    }
    else{
      res.send("Invalid Credentials");
     
        
    }
  });
}
const mid4 = (req,res,next)=>{
    let password = req.body.password;
    let objpassword = {"password": password};
    schema.find(objpassword).then((data) => {
      if(data.length != 0){
        next();
       
      }
      else{
        res.send("Invalid Credentials");
       
        
      }
    });
  }
  
export {mid3 , mid4};