// import cartSchema from "../Modal/CartSchema.js";
// const catdel = (req,res,next)=>{
//     let UserId = req.body.UserId;
//     let objUserId ={"UserId":UserId};
//     cartSchema.find(objUserId).then((data) => {
//           if(data.length != 0){
//             let productId = req.body.productId;
//             console.log(productId)
//     let objproductId ={"productId":productId};
//     cartSchema.find(objproductId).then((data) => {
//       if(data.length != 0)
//       {
//         next();
//       }
//       else{
//         res.send("item is not present in your cart");

//       }
//     });   
//           }
//           else{
//             res.send("item is not present in your cart");

//           }
//         });
//   }

// export {catdel};