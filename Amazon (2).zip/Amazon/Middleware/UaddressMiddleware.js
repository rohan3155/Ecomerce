import addressSchema from "../Modal/UadressSchema.js";
const catdel = (req,res,next)=>{
  let phone = req.body.phone;
  let objphone ={"phone":phone};
  addressSchema.find(objphone).then((data) => {
        if(data.length != 0){
          let house = req.body.house;
  let objhouse ={"house":house};
  addressSchema.find(objhouse).then((data) => {
    if(data.length != 0)
    {
      next();
    }
    else{
      res.send("this address not present");

    }
  });   
        }
        else{
          res.send("this address not present");

        }
      });
}

export {catdel};