import schema from "../Modal/Uschema.js";
const userdel = (req,res,next)=>{
    let phone = req.body.phone;
    let objphone = {"phone": phone};
      schema.find(objphone).then((data) => {
          if(data.length != 0){
            next();
            
          }
          else{
            res.send("user does not exist");

          }
        });
  }

export {userdel};