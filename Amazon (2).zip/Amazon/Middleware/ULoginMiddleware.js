import schema from "../Modal/Uschema.js";
const mid3 = (req,res,next)=>{
  let phone = req.body.phone;
  let objphone = {"phone": phone};
  schema.find(objphone).then((data) => {
    if(data.length != 0){
      let password = req.body.password;
      let objpassword= {"password": password};
      schema.find(objpassword).then((data) => {
        if(data.length != 0){
         
          next();
        }
        else{
          res.send("Invalid Credentials2");
        }
      });
    }
    else{
        res.send("Invalid Credentials1");
    
    }
  });
}
// const mid4 = (req,res,next)=>{
//     let password = req.body.password;
//     let objpassword= {"password": password};
//     schema.find(objpassword).then((data) => {
//       if(data.length != 0){
       
//         next();
//       }
//       else{
//         res.send("Invalid Credentials2");
//       }
//     });
//   }
  const uidc = (req,res,next)=>{
    let phone = req.body.phone;
  let objphone = {"phone": phone};
  schema.find(objphone).then((data) => {
    if(data.length != 0){
        res.send(data)
        
    }
    else{
        res.send("Invalid Credentials1");
    
    }
  });
  }
  
export {mid3 ,uidc};