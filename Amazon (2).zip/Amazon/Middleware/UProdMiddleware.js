import productSchema from "../Modal/Proschema.js";
// const prodpcat = (req,res,next)=>{
//   let parentCategory = req.body.parentCategory;
//   let objparentCategory ={"parentCategory":parentCategory};
//   productSchema.find(objparentCategory).then((data) => {
//         if(data){
//           next();
          
//         }
//         else{
//           res.send("Product does not exist");

//         }
//       });
// }
// const prodcat = (req,res,next)=>{
//     let category = req.body.category;
//     let objcategory ={"category":category};
//     productSchema.find(objcategory).then((data) => {
//           if(data){
//             next();
            
//           }
//           else{
//             res.send("Product  does not exist");

//           }
//         });
//   }
//   const prodScat = (req,res,next)=>{
//     let subcategory = req.body.subcategory;
//     let objsubcategory ={"subcategory":subcategory};
//     productSchema.find(objsubcategory).then((data) => {
//           if(data){
//             next();
            
//           }
//           else{
//             res.send("Product  does not exist");

//           }
//         });
//   }

// export {prodpcat,prodcat,prodScat};