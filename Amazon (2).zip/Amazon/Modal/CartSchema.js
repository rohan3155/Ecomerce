import mongoose from "mongoose";
const cartSchema = mongoose.Schema(
    {
        UserId: {
            type: mongoose.Schema.Types.ObjectId,
            ref:"User"

        },
        productId:{
            type: mongoose.Schema.Types.ObjectId,
            ref:"product"
        },
        quantity: {
            type:String,
            required:true

        },  
    }
)
export default mongoose.model("cart", cartSchema);
