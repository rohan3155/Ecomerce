import mongoose from "mongoose";
const productSchema = mongoose.Schema(
    {
        
        name: {
            type: String,
            required: true
        },
        price: {
            type: Number
        },
        salePrice: {
            type: Number
        },
        description: {
            type: String
        },
        stock: {
            type: Number
        },
        categoryId: {
            type: mongoose.Schema.Types.ObjectId,
            ref:"categories"
        },
       
    }
)
export default mongoose.model("product", productSchema);