import mongoose from "mongoose";
const categorySchema = mongoose.Schema(
    {
      
        category: {
            type: String,
            required: true
        },
        
    }
)
export default mongoose.model("categories", categorySchema);
