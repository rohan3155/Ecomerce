import mongoose from "mongoose";
const addressSchema = mongoose.Schema(
    {
      
        
        state: {
            type: String,
            required: true
        },
        city: {
            type: String,
            required: true
        },
        street: {
            type: String,
            required: true
        },
        house: {
            type: String,
            required: true
        },
        userId: {
            type: mongoose.Schema.Types.ObjectId,
            ref:"User"
          },

        
    }
)
export default mongoose.model("address", addressSchema);
