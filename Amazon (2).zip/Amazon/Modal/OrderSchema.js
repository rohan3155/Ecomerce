import mongoose from "mongoose";
const orderSchema = mongoose.Schema(
    {
       userId:{
            type: mongoose.Schema.Types.ObjectId,
            ref:"User"
        },
        productId:{
            type: mongoose.Schema.Types.ObjectId,
            ref:"product"
        },
        quantity: {
            type:String,
            required:true

        },  
    }
)
export default mongoose.model("order", orderSchema);
