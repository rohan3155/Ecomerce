import mongoose from "mongoose";
const ImageSchema = mongoose.Schema(
    {
        ProductId: {
            type: mongoose.Schema.Types.ObjectId,
            ref:"product"
        },
        ImageId: {
            type: String,
            required: true
        },
        
    }
)
export default mongoose.model("images", ImageSchema);
